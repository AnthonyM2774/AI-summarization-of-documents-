import React from 'react';
import { Brain, Cpu, Zap, Activity, Shield, Hexagon, Triangle } from 'lucide-react';
import { motion } from 'framer-motion';

const ComplexLogo: React.FC = () => (
  <div className="relative">
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
      className="absolute inset-0"
    >
      <Hexagon className="h-12 w-12 text-cyber-400/30" />
    </motion.div>
    <motion.div
      animate={{ rotate: -360 }}
      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
      className="absolute inset-0 scale-75"
    >
      <Shield className="h-12 w-12 text-electric-400/40" />
    </motion.div>
    <motion.div
      animate={{ rotate: 360, scale: [1, 1.1, 1] }}
      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
      className="absolute inset-0 scale-50"
    >
      <Triangle className="h-12 w-12 text-neon-400/50" />
    </motion.div>
    <div className="relative bg-gradient-to-r from-cyber-600 via-electric-600 to-neon-600 p-3 edgy-border shadow-2xl edgy-glow">
      <Brain className="h-6 w-6 text-white" />
    </div>
  </div>
);
export const Header: React.FC = () => {
  return (
    <motion.header 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="relative bg-dark-900/90 backdrop-blur-xl border-b-4 border-cyber-500/40 shadow-2xl sharp-shadow"
    >
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-4 -left-4 w-24 h-24 bg-cyber-500/20 edgy-border blur-xl animate-pulse-slow"></div>
        <div className="absolute -top-2 -right-8 w-32 h-32 bg-electric-500/20 sharp-border blur-xl animate-float"></div>
        <div className="absolute top-1/2 left-1/4 w-2 h-2 bg-neon-400 rounded-full animate-ping"></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-cyber-400 rounded-full animate-ping delay-1000"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-cyber-500/5 via-transparent to-electric-500/5 transform skew-x-12"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          {/* Logo and Title */}
          <motion.div 
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="flex items-center space-x-4"
          >
            <ComplexLogo />
            <div>
              <h1 className="text-3xl font-black font-edgy slant-text bg-gradient-to-r from-cyber-300 via-electric-300 to-neon-300 bg-clip-text text-transparent tracking-wider">
                Neural Document Analyzer
              </h1>
              <p className="text-sm text-gray-300 font-sharp slant-text tracking-widest">
                Advanced Intelligence • Multi-Modal Processing • Deep Analysis
              </p>
            </div>
          </motion.div>

          {/* Status Indicators */}
          <motion.div 
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="hidden lg:flex items-center space-x-6"
          >
            <div className="flex items-center space-x-3">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                className="relative"
              >
                <div className="absolute inset-0 bg-neon-500/30 edgy-border blur-md"></div>
                <div className="relative bg-dark-800 p-3 edgy-border border-2 border-neon-500/50 edgy-glow">
                  <Cpu className="h-4 w-4 text-neon-400" />
                </div>
              </motion.div>
              <div className="text-xs">
                <div className="text-neon-300 font-sharp font-bold slant-text tracking-wider">NEURAL CORE</div>
                <div className="text-gray-400 font-sharp">ACTIVE</div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-electric-500/30 sharp-border blur-md animate-pulse"></div>
                <div className="relative bg-dark-800 p-3 sharp-border border-2 border-electric-500/50 edgy-glow">
                  <Zap className="h-4 w-4 text-electric-400" />
                </div>
              </div>
              <div className="text-xs">
                <div className="text-electric-300 font-sharp font-bold slant-text tracking-wider">PROCESSING</div>
                <div className="text-gray-400 font-sharp">READY</div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-cyber-500/30 edgy-border blur-md"></div>
                <div className="relative bg-dark-800 p-3 edgy-border border-2 border-cyber-500/50 edgy-glow">
                  <Activity className="h-4 w-4 text-cyber-400" />
                </div>
              </div>
              <div className="text-xs">
                <div className="text-cyber-300 font-sharp font-bold slant-text tracking-wider">ANALYSIS</div>
                <div className="text-gray-400 font-sharp">ONLINE</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom glow line */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-cyber-400 to-transparent transform skew-x-12"></div>
    </motion.header>
  );
};