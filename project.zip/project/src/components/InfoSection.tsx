import React from 'react';
import { Brain, Zap, Eye, Shield, Clock, Target, FileText, Image, Layers, Cpu, Database, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

export const InfoSection: React.FC = () => {
  const analysisModules = [
    {
      icon: Brain,
      name: 'Contextual Intelligence',
      description: 'Advanced semantic understanding and domain-specific knowledge extraction',
      color: 'from-cyber-600 to-cyber-500',
      bgColor: 'bg-cyber-500/10',
      features: ['Deep Context Analysis', 'Domain Terminology', 'Semantic Relationships'],
    },
    {
      icon: Zap,
      name: 'Sequential Processing',
      description: 'Document structure analysis and information flow optimization',
      color: 'from-electric-600 to-electric-500',
      bgColor: 'bg-electric-500/10',
      features: ['Pattern Recognition', 'Document Structure', 'Information Flow'],
    },
    {
      icon: Eye,
      name: 'Visual Intelligence',
      description: 'Advanced computer vision for comprehensive visual content analysis',
      color: 'from-neon-600 to-neon-500',
      bgColor: 'bg-neon-500/10',
      features: ['Image Analysis', 'Chart Recognition', 'Visual Context'],
    },
  ];

  const capabilities = [
    {
      icon: FileText,
      title: 'Text Processing',
      description: 'Neural language understanding with domain-specific optimization',
      color: 'text-cyber-400',
    },
    {
      icon: Image,
      title: 'Visual Analysis',
      description: 'Intelligent interpretation of charts, diagrams, and visual elements',
      color: 'text-electric-400',
    },
    {
      icon: Layers,
      title: 'Multi-Modal Fusion',
      description: 'Seamless integration of textual and visual information streams',
      color: 'text-neon-400',
    },
  ];

  const benefits = [
    {
      icon: Shield,
      title: 'Domain Expertise',
      description: 'Specialized neural networks adapted for specific document domains',
      color: 'text-purple-400',
    },
    {
      icon: Clock,
      title: 'Real-Time Processing',
      description: 'Optimized algorithms for rapid analysis and instant results',
      color: 'text-pink-400',
    },
    {
      icon: Target,
      title: 'Precision Analysis',
      description: 'Context-aware understanding with high accuracy and relevance',
      color: 'text-amber-400',
    },
  ];

  return (
    <div className="relative bg-gradient-to-br from-dark-950 to-dark-900 py-20 overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyber-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-electric-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-neon-500/5 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center space-x-3 mb-6">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="p-3 bg-gradient-to-r from-cyber-600 to-electric-600 rounded-xl shadow-lg"
            >
              <Cpu className="h-8 w-8 text-white" />
            </motion.div>
            <h2 className="text-4xl font-bold font-tech bg-gradient-to-r from-cyber-400 via-electric-400 to-neon-400 bg-clip-text text-transparent">
              Neural Document Intelligence
            </h2>
          </div>
          <p className="text-xl text-gray-400 max-w-4xl mx-auto font-mono leading-relaxed">
            Advanced neural processing system combining contextual understanding, sequential analysis, 
            and visual intelligence to provide comprehensive document insights with domain-specific optimization.
          </p>
        </motion.div>

        {/* Analysis Modules */}
        <div className="grid lg:grid-cols-3 gap-8 mb-20">
          {analysisModules.map((module, index) => (
            <motion.div
              key={module.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              viewport={{ once: true }}
              className={`relative group ${module.bgColor} rounded-2xl border border-current/10 p-8 hover:border-current/30 transition-all duration-500 shadow-2xl`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-white/10 opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-500"></div>
              
              <div className="relative">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className={`inline-flex p-4 bg-gradient-to-r ${module.color} rounded-xl shadow-lg mb-6`}
                >
                  <module.icon className="h-8 w-8 text-white" />
                </motion.div>
                
                <h3 className="text-2xl font-bold font-tech text-gray-100 mb-4">
                  {module.name}
                </h3>
                <p className="text-gray-400 font-mono mb-6 leading-relaxed">
                  {module.description}
                </p>
                
                <ul className="space-y-3">
                  {module.features.map((feature, idx) => (
                    <motion.li
                      key={feature}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: (index * 0.2) + (idx * 0.1), duration: 0.4 }}
                      viewport={{ once: true }}
                      className="flex items-center space-x-3"
                    >
                      <div className="w-2 h-2 bg-current rounded-full animate-pulse" />
                      <span className="text-sm text-gray-500 font-mono">{feature}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Core Capabilities */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Database className="h-6 w-6 text-electric-400" />
              <h3 className="text-3xl font-bold font-tech bg-gradient-to-r from-electric-400 to-neon-400 bg-clip-text text-transparent">
                Core Processing Capabilities
              </h3>
            </div>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {capabilities.map((capability, index) => (
              <motion.div
                key={capability.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2, duration: 0.6 }}
                viewport={{ once: true }}
                className="relative group bg-gradient-to-br from-dark-800/50 to-dark-700/50 rounded-xl p-6 border border-dark-600/30 hover:border-gray-500/30 transition-all duration-300 shadow-xl"
              >
                <div className="flex items-start space-x-4">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className={`p-3 bg-gradient-to-r from-dark-700 to-dark-600 rounded-xl ${capability.color}`}
                  >
                    <capability.icon className="h-6 w-6" />
                  </motion.div>
                  <div>
                    <h4 className="text-lg font-bold font-tech text-gray-100 mb-2">
                      {capability.title}
                    </h4>
                    <p className="text-gray-400 font-mono text-sm leading-relaxed">
                      {capability.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* System Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Activity className="h-6 w-6 text-neon-400" />
              <h3 className="text-3xl font-bold font-tech bg-gradient-to-r from-neon-400 to-purple-400 bg-clip-text text-transparent">
                System Advantages
              </h3>
            </div>
          </div>
          
          <div className="grid lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.2, duration: 0.6 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className={`inline-flex p-6 rounded-full bg-gradient-to-r from-dark-800 to-dark-700 border border-current/20 ${benefit.color} mb-6 shadow-2xl`}
                >
                  <benefit.icon className="h-8 w-8" />
                </motion.div>
                <h3 className="text-xl font-bold font-tech text-gray-100 mb-3">
                  {benefit.title}
                </h3>
                <p className="text-gray-400 font-mono leading-relaxed">
                  {benefit.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};