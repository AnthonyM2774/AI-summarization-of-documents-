import React from 'react';
import { AlertTriangle, RefreshCw, Zap, Shield } from 'lucide-react';
import { motion } from 'framer-motion';

interface ErrorDisplayProps {
  error: string;
  onRetry: () => void;
}

export const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ error, onRetry }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="relative bg-gradient-to-br from-red-900/80 to-red-800/80 backdrop-blur-sm border-2 border-red-500/50 rounded-2xl p-8 max-w-2xl mx-auto shadow-2xl"
    >
      {/* Background effects */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden">
        <div className="absolute top-4 right-4 w-32 h-32 bg-red-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-4 left-4 w-24 h-24 bg-red-500/5 rounded-full blur-2xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative">
        <div className="flex items-start space-x-4">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="p-4 bg-gradient-to-r from-red-600 to-red-500 rounded-xl shadow-lg flex-shrink-0"
          >
            <AlertTriangle className="h-8 w-8 text-white" />
          </motion.div>
          
          <div className="flex-1">
            <h3 className="text-2xl font-bold font-tech text-red-400 mb-3">
              Neural Processing Error
            </h3>
            <div className="bg-dark-900/50 rounded-xl p-4 border border-red-500/20 mb-6">
              <p className="text-red-300 font-mono text-sm leading-relaxed">
                {error}
              </p>
            </div>
            
            <div className="flex flex-col lg:flex-row gap-6">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onRetry}
                className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white font-semibold font-tech rounded-xl shadow-lg transition-all duration-300 neural-glow"
              >
                <RefreshCw className="h-5 w-5 mr-3" />
                Reinitialize Process
              </motion.button>
              
              <div className="bg-gradient-to-r from-dark-800/50 to-dark-700/50 rounded-xl p-4 border border-red-500/20">
                <div className="flex items-center space-x-2 mb-3">
                  <Shield className="h-4 w-4 text-red-400" />
                  <span className="font-semibold font-tech text-red-400 text-sm">
                    Diagnostic Solutions
                  </span>
                </div>
                <ul className="space-y-2 text-xs text-gray-400 font-mono">
                  <li className="flex items-center space-x-2">
                    <Zap className="h-3 w-3 text-red-500" />
                    <span>Verify document contains readable text content</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="h-3 w-3 text-red-500" />
                    <span>Check network connectivity and API endpoints</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="h-3 w-3 text-red-500" />
                    <span>Ensure PDF file size is within processing limits</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Zap className="h-3 w-3 text-red-500" />
                    <span>Validate neural processing configuration</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};