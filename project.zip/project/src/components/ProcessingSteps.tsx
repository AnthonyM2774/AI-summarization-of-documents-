import React from 'react';
import { CheckCircle, Clock, AlertCircle, Loader2, Zap, Brain, Eye, Database, Cpu } from 'lucide-react';
import { motion } from 'framer-motion';
import { ProcessingStep } from '../types';

interface ProcessingStepsProps {
  steps: ProcessingStep[];
}

export const ProcessingSteps: React.FC<ProcessingStepsProps> = ({ steps }) => {
  const getStepIcon = (status: ProcessingStep['status'], stepId: string) => {
    const iconProps = { className: "h-5 w-5" };
    
    if (status === 'processing') {
      return <Loader2 {...iconProps} className="h-5 w-5 text-cyber-400 animate-spin" />;
    }
    
    switch (status) {
      case 'completed':
        return <CheckCircle {...iconProps} className="h-5 w-5 text-neon-400" />;
      case 'error':
        return <AlertCircle {...iconProps} className="h-5 w-5 text-red-400" />;
      default:
        // Different icons for different steps
        switch (stepId) {
          case '1':
            return <Database {...iconProps} className="h-5 w-5 text-gray-500" />;
          case '2':
            return <Brain {...iconProps} className="h-5 w-5 text-gray-500" />;
          case '3':
            return <Cpu {...iconProps} className="h-5 w-5 text-gray-500" />;
          case '4':
            return <Zap {...iconProps} className="h-5 w-5 text-gray-500" />;
          case '5':
            return <Eye {...iconProps} className="h-5 w-5 text-gray-500" />;
          default:
            return <Clock {...iconProps} className="h-5 w-5 text-gray-500" />;
        }
    }
  };

  const getStepColors = (status: ProcessingStep['status']) => {
    switch (status) {
      case 'completed':
        return {
          bg: 'from-neon-900/30 to-neon-800/30',
          border: 'border-neon-500/30',
          text: 'text-neon-300',
          glow: 'shadow-neon-500/20'
        };
      case 'processing':
        return {
          bg: 'from-cyber-900/30 to-electric-900/30',
          border: 'border-cyber-500/50',
          text: 'text-cyber-300',
          glow: 'shadow-cyber-500/30'
        };
      case 'error':
        return {
          bg: 'from-red-900/30 to-red-800/30',
          border: 'border-red-500/30',
          text: 'text-red-300',
          glow: 'shadow-red-500/20'
        };
      default:
        return {
          bg: 'from-dark-800/30 to-dark-700/30',
          border: 'border-dark-600/30',
          text: 'text-gray-400',
          glow: 'shadow-dark-500/10'
        };
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative bg-gradient-to-br from-dark-800/80 to-dark-700/80 backdrop-blur-sm rounded-2xl border border-cyber-500/20 p-8 shadow-2xl"
    >
      {/* Background effects */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyber-500/50 to-transparent"></div>
        <div className="absolute -top-4 left-1/4 w-24 h-24 bg-electric-500/5 rounded-full blur-2xl animate-pulse"></div>
        <div className="absolute -bottom-4 right-1/4 w-32 h-32 bg-cyber-500/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative">
        <div className="flex items-center space-x-3 mb-8">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="p-3 bg-gradient-to-r from-cyber-600 to-electric-600 rounded-xl shadow-lg"
          >
            <Cpu className="h-6 w-6 text-white" />
          </motion.div>
          <div>
            <h3 className="text-xl font-bold font-tech bg-gradient-to-r from-gray-200 to-gray-400 bg-clip-text text-transparent">
              Neural Processing Pipeline
            </h3>
            <p className="text-sm text-gray-400 font-mono">
              Real-time analysis progression monitoring
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {steps.map((step, index) => {
            const colors = getStepColors(step.status);
            
            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className={`relative group bg-gradient-to-r ${colors.bg} border ${colors.border} rounded-xl p-6 transition-all duration-500 ${colors.glow} shadow-xl`}
              >
                {/* Processing animation overlay */}
                {step.status === 'processing' && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyber-500/10 to-transparent animate-scan rounded-xl"></div>
                )}

                <div className="relative flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <motion.div
                      animate={step.status === 'processing' ? { scale: [1, 1.1, 1] } : {}}
                      transition={{ duration: 1, repeat: step.status === 'processing' ? Infinity : 0 }}
                      className={`p-3 rounded-xl ${
                        step.status === 'completed' 
                          ? 'bg-gradient-to-r from-neon-600 to-neon-500' 
                          : step.status === 'processing'
                          ? 'bg-gradient-to-r from-cyber-600 to-electric-600'
                          : step.status === 'error'
                          ? 'bg-gradient-to-r from-red-600 to-red-500'
                          : 'bg-gradient-to-r from-dark-600 to-dark-500'
                      } shadow-lg`}
                    >
                      {getStepIcon(step.status, step.id)}
                    </motion.div>
                    
                    <div>
                      <span className={`font-semibold font-tech text-lg ${colors.text}`}>
                        {step.name}
                      </span>
                      <div className="flex items-center space-x-2 mt-1">
                        <div className={`w-2 h-2 rounded-full ${
                          step.status === 'completed' ? 'bg-neon-400 animate-pulse' :
                          step.status === 'processing' ? 'bg-cyber-400 animate-ping' :
                          step.status === 'error' ? 'bg-red-400' :
                          'bg-gray-600'
                        }`}></div>
                        <span className="text-xs font-mono text-gray-500 uppercase tracking-wider">
                          {step.status === 'processing' ? 'Active' : 
                           step.status === 'completed' ? 'Complete' :
                           step.status === 'error' ? 'Error' : 'Pending'}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {step.status === 'processing' && (
                    <div className="flex items-center space-x-4">
                      <div className="w-32 bg-dark-700 rounded-full h-3 overflow-hidden">
                        <motion.div
                          className="bg-gradient-to-r from-cyber-500 to-electric-500 h-full rounded-full shadow-lg"
                          initial={{ width: 0 }}
                          animate={{ width: `${step.progress}%` }}
                          transition={{ duration: 0.5, ease: "easeOut" }}
                        />
                      </div>
                      <span className="text-sm font-mono font-bold text-cyber-400 min-w-[3rem]">
                        {step.progress}%
                      </span>
                    </div>
                  )}
                </div>

                {/* Completion glow effect */}
                {step.status === 'completed' && (
                  <div className="absolute inset-0 bg-gradient-to-r from-neon-500/10 to-neon-400/10 rounded-xl animate-pulse"></div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
};