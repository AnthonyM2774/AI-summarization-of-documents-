import React from 'react';
import { BookOpen, Building2, Stethoscope, Scale, TrendingUp, Cpu, GraduationCap, Globe, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

interface DomainSelectorProps {
  selectedDomain: string;
  onDomainChange: (domain: string) => void;
}

export const DomainSelector: React.FC<DomainSelectorProps> = ({
  selectedDomain,
  onDomainChange,
}) => {
  const domains = [
    {
      id: 'general',
      name: 'General',
      icon: Globe,
      description: 'Universal document analysis protocol',
      color: 'from-gray-600 to-gray-500',
      borderColor: 'border-gray-500/30',
      glowColor: 'shadow-gray-500/20',
    },
    {
      id: 'academic',
      name: 'Academic',
      icon: GraduationCap,
      description: 'Research papers, theses, scholarly publications',
      color: 'from-cyber-600 to-cyber-500',
      borderColor: 'border-cyber-500/30',
      glowColor: 'shadow-cyber-500/20',
    },
    {
      id: 'business',
      name: 'Business',
      icon: Building2,
      description: 'Reports, proposals, strategic documents',
      color: 'from-blue-600 to-blue-500',
      borderColor: 'border-blue-500/30',
      glowColor: 'shadow-blue-500/20',
    },
    {
      id: 'medical',
      name: 'Medical',
      icon: Stethoscope,
      description: 'Medical reports, clinical studies, healthcare',
      color: 'from-red-600 to-red-500',
      borderColor: 'border-red-500/30',
      glowColor: 'shadow-red-500/20',
    },
    {
      id: 'legal',
      name: 'Legal',
      icon: Scale,
      description: 'Legal documents, contracts, case studies',
      color: 'from-amber-600 to-amber-500',
      borderColor: 'border-amber-500/30',
      glowColor: 'shadow-amber-500/20',
    },
    {
      id: 'financial',
      name: 'Financial',
      icon: TrendingUp,
      description: 'Financial reports, market analysis, statements',
      color: 'from-emerald-600 to-emerald-500',
      borderColor: 'border-emerald-500/30',
      glowColor: 'shadow-emerald-500/20',
    },
    {
      id: 'technical',
      name: 'Technical',
      icon: Cpu,
      description: 'Technical manuals, specifications, engineering',
      color: 'from-purple-600 to-purple-500',
      borderColor: 'border-purple-500/30',
      glowColor: 'shadow-purple-500/20',
    },
    {
      id: 'educational',
      name: 'Educational',
      icon: BookOpen,
      description: 'Textbooks, course materials, learning resources',
      color: 'from-pink-600 to-pink-500',
      borderColor: 'border-pink-500/30',
      glowColor: 'shadow-pink-500/20',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative bg-gradient-to-br from-dark-800/80 to-dark-700/80 backdrop-blur-sm rounded-2xl border border-cyber-500/20 p-8 shadow-2xl"
    >
      {/* Background effects */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden">
        <div className="absolute top-4 right-4 w-32 h-32 bg-electric-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-4 left-4 w-24 h-24 bg-cyber-500/5 rounded-full blur-2xl"></div>
      </div>

      <div className="relative">
        <div className="flex items-center space-x-3 mb-6">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="p-3 bg-gradient-to-r from-cyber-600 to-electric-600 rounded-xl"
          >
            <Zap className="h-6 w-6 text-white" />
          </motion.div>
          <div>
            <h3 className="text-xl font-bold font-tech bg-gradient-to-r from-gray-200 to-gray-400 bg-clip-text text-transparent">
              Neural Domain Configuration
            </h3>
            <p className="text-sm text-gray-400 font-mono">
              Select optimal processing parameters for document type
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {domains.map((domain, index) => (
            <motion.button
              key={domain.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
              whileHover={{ scale: 1.05, y: -5 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onDomainChange(domain.id)}
              className={`relative group p-4 rounded-xl border-2 transition-all duration-300 ${
                selectedDomain === domain.id
                  ? `bg-gradient-to-br ${domain.color} border-white/30 shadow-2xl ${domain.glowColor}`
                  : `bg-gradient-to-br from-dark-700 to-dark-600 ${domain.borderColor} hover:${domain.borderColor.replace('/30', '/50')} hover:shadow-xl hover:${domain.glowColor}`
              }`}
            >
              {/* Selection indicator */}
              {selectedDomain === domain.id && (
                <motion.div
                  layoutId="selectedDomain"
                  className="absolute inset-0 bg-gradient-to-r from-white/10 to-white/5 rounded-xl"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}

              {/* Hover effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl"></div>

              <div className="relative">
                <div className={`inline-flex p-3 rounded-lg mb-3 bg-gradient-to-br ${domain.color} shadow-lg`}>
                  <domain.icon className="h-5 w-5 text-white" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-100 font-tech mb-1">
                    {domain.name}
                  </div>
                  <div className="text-xs text-gray-400 leading-tight font-mono">
                    {domain.description}
                  </div>
                </div>
              </div>

              {/* Active pulse */}
              {selectedDomain === domain.id && (
                <div className="absolute -inset-1 bg-gradient-to-r from-white/20 to-white/10 rounded-xl blur-sm animate-pulse"></div>
              )}
            </motion.button>
          ))}
        </div>
        
        {selectedDomain !== 'general' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="relative bg-gradient-to-r from-cyber-900/30 to-electric-900/30 border border-cyber-500/30 rounded-xl p-4 backdrop-blur-sm"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-cyber-500/5 to-electric-500/5 rounded-xl"></div>
            <div className="relative flex items-start space-x-3">
              <div className="p-2 bg-gradient-to-r from-cyber-600 to-electric-600 rounded-lg">
                <Zap className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-300 font-mono leading-relaxed">
                  <span className="text-cyber-400 font-semibold">Neural Adaptation Active:</span> The analysis engine will optimize processing algorithms 
                  for <span className="text-electric-400 font-semibold">
                    {domains.find(d => d.id === selectedDomain)?.name.toLowerCase()}
                  </span> domain patterns, enhancing accuracy for specialized terminology, 
                  document structures, and domain-specific content relationships.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};