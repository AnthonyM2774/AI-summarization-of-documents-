import React from 'react';
import { FileText, Image, Hash, Clock, Eye, Tag, Database, Zap, Brain, Scan } from 'lucide-react';
import { motion } from 'framer-motion';
import { ExtractedContent } from '../types';

interface ExtractedContentProps {
  content: ExtractedContent;
  onImageAnalysis?: () => void;
}

export const ExtractedContentDisplay: React.FC<ExtractedContentProps> = ({ content, onImageAnalysis }) => {
  const stats = [
    {
      icon: FileText,
      label: 'Pages',
      value: content.pageCount,
      color: 'from-cyber-600 to-cyber-500',
      bgColor: 'bg-cyber-500/10',
      textColor: 'text-cyber-400',
    },
    {
      icon: Hash,
      label: 'Words',
      value: content.wordCount.toLocaleString(),
      color: 'from-electric-600 to-electric-500',
      bgColor: 'bg-electric-500/10',
      textColor: 'text-electric-400',
    },
    {
      icon: Image,
      label: 'Visuals',
      value: content.imageCount,
      color: 'from-neon-600 to-neon-500',
      bgColor: 'bg-neon-500/10',
      textColor: 'text-neon-400',
    },
    {
      icon: Clock,
      label: 'Est. Time',
      value: `${Math.ceil(content.wordCount / 200)}m`,
      color: 'from-purple-600 to-purple-500',
      bgColor: 'bg-purple-500/10',
      textColor: 'text-purple-400',
    },
  ];

  const getDomainConfig = (domain: string) => {
    const configs = {
      general: { color: 'from-gray-600 to-gray-500', bg: 'bg-gray-500/10', text: 'text-gray-400' },
      academic: { color: 'from-blue-600 to-blue-500', bg: 'bg-blue-500/10', text: 'text-blue-400' },
      business: { color: 'from-indigo-600 to-indigo-500', bg: 'bg-indigo-500/10', text: 'text-indigo-400' },
      medical: { color: 'from-red-600 to-red-500', bg: 'bg-red-500/10', text: 'text-red-400' },
      legal: { color: 'from-amber-600 to-amber-500', bg: 'bg-amber-500/10', text: 'text-amber-400' },
      financial: { color: 'from-emerald-600 to-emerald-500', bg: 'bg-emerald-500/10', text: 'text-emerald-400' },
      technical: { color: 'from-purple-600 to-purple-500', bg: 'bg-purple-500/10', text: 'text-purple-400' },
      educational: { color: 'from-pink-600 to-pink-500', bg: 'bg-pink-500/10', text: 'text-pink-400' },
    };
    return configs[domain] || configs.general;
  };

  const domainConfig = getDomainConfig(content.domain || 'general');

  return (
    <>
      {/* Document Analysis Overview */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative bg-gradient-to-br from-dark-800/90 to-dark-700/90 backdrop-blur-sm edgy-border border-2 border-cyber-500/40 p-8 shadow-2xl edgy-glow hover:border-cyber-400/60 transition-all duration-500 group"
      >
        {/* Background effects */}
        <div className="absolute inset-0 rounded-2xl overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyber-500/60 to-transparent group-hover:via-cyber-400/80 transition-all duration-500"></div>
          <div className="absolute top-4 right-4 w-32 h-32 bg-electric-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-4 left-4 w-24 h-24 bg-cyber-500/10 rounded-full blur-2xl animate-pulse delay-1000"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        </div>

        <div className="relative">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="p-4 bg-gradient-to-r from-cyber-600 to-electric-600 edgy-border shadow-2xl edgy-glow"
              >
                <Database className="h-8 w-8 text-white" />
              </motion.div>
              <div>
                <h3 className="text-3xl font-black font-edgy slant-text bg-gradient-to-r from-cyber-300 via-electric-300 to-neon-300 bg-clip-text text-transparent tracking-wider">
                  Document Analysis Matrix
                </h3>
                <p className="text-sm text-gray-300 font-sharp slant-text tracking-widest uppercase">
                  Neural Extraction • Content Mapping • Data Intelligence
                </p>
              </div>
            </div>
            
            {content.domain && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3, type: "spring", bounce: 0.5 }}
                className={`inline-flex items-center space-x-2 px-6 py-3 edgy-border ${domainConfig.bg} border-2 border-current/40 ${domainConfig.text} edgy-glow hover:border-current/60 transition-all duration-300`}
              >
                <Tag className="h-5 w-5" />
                <span className="font-sharp font-black text-sm uppercase tracking-widest slant-text">
                  {content.domain}
                </span>
              </motion.div>
            )}
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className={`relative group ${stat.bgColor} edgy-border p-4 border-2 border-current/30 hover:border-current/60 transition-all duration-300 edgy-glow cursor-pointer`}
              >
                <div className="flex flex-col items-center text-center space-y-2">
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: 10 }}
                    className={`p-3 bg-gradient-to-r ${stat.color} edgy-border shadow-xl edgy-glow`}
                  >
                    <stat.icon className="h-5 w-5 text-white" />
                  </motion.div>
                  <div>
                    <div className={`text-2xl font-black font-edgy slant-text ${stat.textColor} tracking-wider`}>
                      {stat.value}
                    </div>
                    <div className="text-xs text-gray-400 font-sharp uppercase tracking-widest slant-text">
                      {stat.label}
                    </div>
                  </div>
                </div>
                
                {/* Hover glow effect */}
                <div className={`absolute inset-0 bg-gradient-to-r ${stat.color} opacity-0 group-hover:opacity-10 edgy-border transition-opacity duration-300`}></div>
              </motion.div>
            ))}
          </div>

          <div className="border-t-2 border-cyber-500/30 pt-4">
            <div className="flex items-center space-x-3 mb-4">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="p-2 bg-gradient-to-r from-cyber-600 to-electric-600 edgy-border"
              >
                <Brain className="h-4 w-4 text-white" />
              </motion.div>
              <h4 className="font-black font-edgy text-cyber-300 slant-text tracking-widest uppercase">Content Intelligence Preview</h4>
            </div>
            <div className="relative bg-dark-900/60 edgy-border p-4 border-2 border-cyber-500/30 max-h-32 overflow-y-auto edgy-glow hover:border-cyber-400/50 transition-all duration-300 group">
              <div className="absolute inset-0 bg-gradient-to-r from-cyber-500/10 to-electric-500/10 edgy-border"></div>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <p className="relative text-xs text-gray-300 leading-relaxed font-sharp tracking-wide">
                {content.text.substring(0, 500)}
                {content.text.length > 500 && (
                  <span className="text-cyber-400 italic font-bold">... [NEURAL PREVIEW TRUNCATED]</span>
                )}
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Visual Content Analysis */}
      {content.images && content.images.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="relative bg-gradient-to-br from-dark-800/90 to-dark-700/90 backdrop-blur-sm edgy-border border-2 border-electric-500/40 p-8 shadow-2xl edgy-glow hover:border-electric-400/60 transition-all duration-500 group"
        >
          {/* Background effects */}
          <div className="absolute inset-0 rounded-2xl overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-electric-500/60 to-transparent group-hover:via-electric-400/80 transition-all duration-500"></div>
            <div className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-r from-transparent via-neon-500/60 to-transparent group-hover:via-neon-400/80 transition-all duration-500"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          </div>

          <div className="relative">
            <div className="flex items-center space-x-3 mb-6">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center space-x-3">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="p-4 bg-gradient-to-r from-electric-600 to-neon-600 edgy-border shadow-2xl edgy-glow"
                  >
                    <Eye className="h-8 w-8 text-white" />
                  </motion.div>
                  <div>
                    <h3 className="text-3xl font-black font-edgy slant-text bg-gradient-to-r from-electric-300 via-neon-300 to-purple-300 bg-clip-text text-transparent tracking-wider">
                      Visual Intelligence Analysis
                    </h3>
                    <p className="text-sm text-gray-300 font-sharp slant-text tracking-widest uppercase">
                      {content.images.length} Visual Element{content.images.length !== 1 ? 's' : ''} • Neural Processing • Deep Analysis
                    </p>
                  </div>
                </div>
                
                {onImageAnalysis && (
                  <motion.button
                    whileHover={{ scale: 1.05, rotate: 2 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={onImageAnalysis}
                    className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-neon-600 via-purple-600 to-pink-600 hover:from-neon-500 hover:via-purple-500 hover:to-pink-500 text-white font-black font-edgy slant-text edgy-border shadow-2xl transition-all duration-300 edgy-glow tracking-widest uppercase"
                  >
                    <Scan className="h-6 w-6 mr-3" />
                    DEEP VISUAL SCAN
                  </motion.button>
                )}
              </div>
            </div>
            
            <div className="space-y-4">
              {content.images.map((image, index) => (
                <motion.div
                  key={image.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.2, duration: 0.5 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="relative bg-gradient-to-r from-dark-800/60 to-dark-700/60 edgy-border border-2 border-electric-500/40 overflow-hidden shadow-2xl edgy-glow hover:border-electric-400/60 transition-all duration-300 group cursor-pointer"
                >
                  <div className="bg-gradient-to-r from-electric-900/50 to-neon-900/50 p-4 border-b-2 border-electric-500/40 group-hover:border-electric-400/60 transition-all duration-300">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                          className="p-2 bg-gradient-to-r from-electric-600 to-neon-600 edgy-border"
                        >
                          <Zap className="h-3 w-3 text-white" />
                        </motion.div>
                        <span className="font-black font-edgy slant-text text-electric-300 tracking-widest uppercase">
                          Page {image.pageNumber} • Visual Intelligence
                        </span>
                      </div>
                      <span className="text-xs text-gray-400 font-sharp slant-text tracking-widest uppercase">
                        {Math.round(image.width)}×{Math.round(image.height)}px
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <div className="mb-4">
                      <img
                        src={image.dataUrl}
                        alt={`Visual content from page ${image.pageNumber}`}
                        className="w-full h-auto max-h-48 object-contain bg-dark-900/60 edgy-border border-2 border-dark-600/50 shadow-xl edgy-glow hover:border-electric-400/40 transition-all duration-300"
                        loading="lazy"
                      />
                    </div>
                    
                    {image.explanation && (
                      <div className="relative bg-gradient-to-r from-electric-900/40 to-neon-900/40 border-2 border-electric-500/40 edgy-border p-4 edgy-glow hover:border-electric-400/60 transition-all duration-300 group">
                        <div className="absolute inset-0 bg-gradient-to-r from-electric-500/10 to-neon-500/10 edgy-border"></div>
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        <div className="relative">
                          <div className="flex items-center space-x-2 mb-2">
                            <motion.div
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ duration: 2, repeat: Infinity }}
                              className="p-1 bg-gradient-to-r from-electric-600 to-neon-600 edgy-border"
                            >
                              <Brain className="h-3 w-3 text-white" />
                            </motion.div>
                            <h5 className="font-black font-edgy slant-text text-electric-300 tracking-widest uppercase">
                              Neural Analysis Result
                            </h5>
                          </div>
                          <p className="text-xs text-gray-200 leading-relaxed font-sharp tracking-wide">
                            {image.explanation}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </>
  );
};