import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, Loader2, Presentation, Zap, Database, Brain } from 'lucide-react';
import { generatePowerPoint } from '../services/pptService';

export interface SummaryResult {
  id: string;
  model: 'bert' | 'lstm' | 'multimodel';
  title: string;
  content: string;
  confidence: number;
  processingTime: number;
  keyPoints: string[];
  domain?: string;
}

export interface ExtractedContent {
  text: string;
  imageCount: number;
  pageCount: number;
  wordCount: number;
  images: ExtractedImage[];
  domain?: string;
}

export interface ExtractedImage {
  id: string;
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  explanation?: string;
}

export interface ProcessingStep {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}

interface PPTGeneratorProps {
  extractedContent: ExtractedContent;
  summaryResults: SummaryResult[];
  fileName: string;
}

export const PPTGenerator: React.FC<PPTGeneratorProps> = ({
  extractedContent,
  summaryResults,
  fileName
}) => {
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGeneratePPT = async () => {
    setIsGenerating(true);
    try {
      await generatePowerPoint(extractedContent, summaryResults, fileName);
    } catch (error) {
      console.error('Error generating PowerPoint:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative bg-gradient-to-br from-dark-800/80 to-dark-700/80 backdrop-blur-sm rounded-2xl border border-electric-500/20 p-8 shadow-2xl"
    >
      {/* Background effects */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden">
        <div className="absolute top-4 right-4 w-32 h-32 bg-electric-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-4 left-4 w-24 h-24 bg-cyber-500/5 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-500"></div>
      </div>

      <div className="relative">
        <div className="flex items-center space-x-4 mb-6">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="p-4 bg-gradient-to-r from-electric-600 to-neon-600 rounded-xl shadow-lg"
          >
            <Presentation className="h-8 w-8 text-white" />
          </motion.div>
          <div>
            <h3 className="text-2xl font-bold font-tech bg-gradient-to-r from-electric-400 to-neon-400 bg-clip-text text-transparent">
              Neural Presentation Generator
            </h3>
            <p className="text-sm text-gray-400 font-mono">
              Transform analysis into comprehensive presentation format
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-dark-900/50 to-dark-800/50 rounded-xl p-6 border border-dark-600/30 mb-6">
          <div className="grid grid-cols-2 gap-6 text-sm">
            <div className="flex items-center space-x-3">
              <FileText className="h-4 w-4 text-cyber-400" />
              <div>
                <span className="font-semibold text-gray-300 font-tech">Source Document:</span>
                <div className="text-gray-400 font-mono truncate">{fileName}</div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Database className="h-4 w-4 text-electric-400" />
              <div>
                <span className="font-semibold text-gray-300 font-tech">Content Pages:</span>
                <div className="text-gray-400 font-mono">{extractedContent.pageCount}</div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Zap className="h-4 w-4 text-neon-400" />
              <div>
                <span className="font-semibold text-gray-300 font-tech">Visual Elements:</span>
                <div className="text-gray-400 font-mono">{extractedContent.imageCount}</div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Brain className="h-4 w-4 text-purple-400" />
              <div>
                <span className="font-semibold text-gray-300 font-tech">Analysis Modules:</span>
                <div className="text-gray-400 font-mono">{summaryResults.length}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-4">
            <Presentation className="h-5 w-5 text-electric-400" />
            <h4 className="font-semibold font-tech text-gray-300">Presentation Structure</h4>
          </div>
          <div className="bg-dark-900/30 rounded-xl p-4 border border-dark-600/30">
            <ul className="space-y-2 text-sm text-gray-400 font-mono">
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-cyber-400 rounded-full animate-pulse"></div>
                <span>Document overview and structural analysis framework</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-electric-400 rounded-full animate-pulse delay-200"></div>
                <span>Comprehensive concept breakdown with detailed explanations</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-neon-400 rounded-full animate-pulse delay-400"></div>
                <span>Advanced visual content analysis with neural interpretation</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse delay-600"></div>
                <span>Statistical data extraction and quantitative insights</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-pink-400 rounded-full animate-pulse delay-800"></div>
                <span>Key findings synthesis and practical implications</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse delay-1000"></div>
                <span>Multi-slide detailed coverage ensuring comprehensive understanding</span>
              </li>
            </ul>
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleGeneratePPT}
          disabled={isGenerating}
          className="w-full inline-flex items-center justify-center px-8 py-4 bg-gradient-to-r from-electric-600 to-neon-600 hover:from-electric-500 hover:to-neon-500 disabled:from-gray-600 disabled:to-gray-500 text-white font-bold font-tech rounded-xl shadow-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed neural-glow"
        >
          {isGenerating ? (
            <>
              <Loader2 className="h-6 w-6 mr-3 animate-spin" />
              <span>Generating Neural Presentation...</span>
            </>
          ) : (
            <>
              <Download className="h-6 w-6 mr-3" />
              <span>Generate Comprehensive Analysis</span>
            </>
          )}
        </motion.button>

        {isGenerating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-4 text-center"
          >
            <div className="inline-flex items-center space-x-2 text-sm text-gray-400 font-mono">
              <div className="w-2 h-2 bg-electric-400 rounded-full animate-ping"></div>
              <span>Neural processing in progress... This may take a few moments</span>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};