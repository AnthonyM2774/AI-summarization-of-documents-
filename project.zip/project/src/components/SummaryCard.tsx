import React from 'react';
import { Brain, Zap, Sparkles, Copy, Check, Activity, Cpu, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { SummaryResult } from '../types';

interface SummaryCardProps {
  summary: SummaryResult;
  index: number;
}

export const SummaryCard: React.FC<SummaryCardProps> = ({ summary, index }) => {
  const [copied, setCopied] = React.useState(false);

  const getModelConfig = (model: SummaryResult['model']) => {
    switch (model) {
      case 'bert':
        return {
          icon: Brain,
          name: 'Contextual Analysis',
          description: 'Deep semantic understanding',
          colors: {
            bg: 'from-cyber-900/30 to-cyber-800/30',
            border: 'border-cyber-500/30',
            icon: 'from-cyber-600 to-cyber-500',
            text: 'text-cyber-400',
            glow: 'shadow-cyber-500/20'
          }
        };
      case 'lstm':
        return {
          icon: Zap,
          name: 'Sequential Processing',
          description: 'Document flow analysis',
          colors: {
            bg: 'from-electric-900/30 to-electric-800/30',
            border: 'border-electric-500/30',
            icon: 'from-electric-600 to-electric-500',
            text: 'text-electric-400',
            glow: 'shadow-electric-500/20'
          }
        };
      case 'multimodel':
        return {
          icon: Eye,
          name: 'Comprehensive Analysis',
          description: 'Multi-modal integration',
          colors: {
            bg: 'from-neon-900/30 to-neon-800/30',
            border: 'border-neon-500/30',
            icon: 'from-neon-600 to-neon-500',
            text: 'text-neon-400',
            glow: 'shadow-neon-500/20'
          }
        };
    }
  };

  const modelConfig = getModelConfig(summary.model);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(summary.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay: index * 0.2, duration: 0.6, ease: "easeOut" }}
      whileHover={{ scale: 1.02, y: -5 }}
      className={`relative group bg-gradient-to-br ${modelConfig.colors.bg} backdrop-blur-sm edgy-border border-2 ${modelConfig.colors.border} p-8 shadow-2xl ${modelConfig.colors.glow} hover:shadow-3xl hover:border-opacity-80 transition-all duration-500 cursor-pointer`}
    >
      {/* Background effects */}
      <div className="absolute inset-0 edgy-border overflow-hidden">
        <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-current/60 to-transparent group-hover:via-current/80 transition-all duration-500`}></div>
        <div className={`absolute top-4 right-4 w-32 h-32 bg-gradient-to-r ${modelConfig.colors.icon} opacity-10 rounded-full blur-3xl animate-pulse`}></div>
        <div className="absolute bottom-4 left-4 w-24 h-24 bg-white/10 rounded-full blur-2xl animate-pulse delay-1000"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      </div>

      <div className="relative">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <motion.div
              whileHover={{ scale: 1.2, rotate: 10 }}
              className={`relative p-4 bg-gradient-to-r ${modelConfig.colors.icon} edgy-border shadow-2xl edgy-glow`}
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${modelConfig.colors.icon} edgy-border blur-lg opacity-50`}></div>
              <modelConfig.icon className="relative h-8 w-8 text-white" />
            </motion.div>
            <div>
              <h3 className="font-black text-2xl font-edgy slant-text text-gray-100 mb-1 tracking-wider">
                {summary.title}
              </h3>
              <div className="flex items-center space-x-3 text-sm">
                <span className={`${modelConfig.colors.text} font-sharp font-black slant-text tracking-widest uppercase`}>
                  {modelConfig.name}
                </span>
                <span className="text-gray-500">•</span>
                <div className="flex items-center space-x-1">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                  >
                    <Activity className="h-3 w-3 text-gray-500" />
                  </motion.div>
                  <span className="text-gray-500 font-sharp slant-text tracking-wider">{summary.processingTime}ms</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Confidence indicator */}
            <div className="flex items-center space-x-3">
              <div className="text-right">
                <div className={`text-xl font-black font-edgy slant-text ${modelConfig.colors.text} tracking-wider`}>
                  {Math.round(summary.confidence * 100)}%
                </div>
                <div className="text-xs text-gray-500 font-sharp uppercase tracking-widest slant-text">
                  Confidence
                </div>
              </div>
              <div className="relative w-20 h-20">
                <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-dark-700"
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <motion.path
                    className={modelConfig.colors.text}
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="none"
                    strokeLinecap="round"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    initial={{ strokeDasharray: "0 100" }}
                    animate={{ strokeDasharray: `${summary.confidence * 100} 100` }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                  >
                    <Cpu className={`h-5 w-5 ${modelConfig.colors.text}`} />
                  </motion.div>
                </div>
              </div>
            </div>

            {/* Copy button */}
            <motion.button
              whileHover={{ scale: 1.2, rotate: 5 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleCopy}
              className="p-3 edgy-border bg-dark-700 hover:bg-dark-600 border-2 border-dark-600 hover:border-gray-400 text-gray-200 hover:text-white transition-all duration-300 edgy-glow"
            >
              {copied ? (
                <Check className="h-5 w-5 text-neon-400" />
              ) : (
                <Copy className="h-5 w-5" />
              )}
            </motion.button>
          </div>
        </div>

        {/* Content */}
        <div className="mb-6">
          <div className="bg-dark-900/40 edgy-border p-6 border-2 border-dark-600/40 hover:border-dark-500/60 transition-all duration-300 group">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 edgy-border"></div>
            <p className="relative text-gray-300 leading-relaxed font-sharp text-sm tracking-wide">
              {summary.content}
            </p>
          </div>
        </div>

        {/* Key Points */}
        <div className="border-t-2 border-gray-700/40 pt-6">
          <div className="flex items-center space-x-2 mb-4">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className={`p-2 bg-gradient-to-r ${modelConfig.colors.icon} edgy-border`}
            >
              <Sparkles className="h-3 w-3 text-white" />
            </motion.div>
            <h4 className="font-black font-edgy slant-text text-gray-200 tracking-widest uppercase">Key Intelligence Points</h4>
          </div>
          <div className="space-y-3">
            {summary.keyPoints.map((point, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: (index * 0.2) + (idx * 0.1), duration: 0.4 }}
                whileHover={{ x: 5, scale: 1.02 }}
                className="flex items-start space-x-3 group cursor-pointer p-2 edgy-border border border-transparent hover:border-current/20 hover:bg-current/5 transition-all duration-300"
              >
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: idx * 0.2 }}
                  className={`w-3 h-3 ${modelConfig.colors.text.replace('text-', 'bg-')} edgy-border mt-1 flex-shrink-0`} 
                />
                <span className="text-sm text-gray-400 leading-relaxed font-sharp tracking-wide group-hover:text-gray-200 transition-colors duration-300">
                  {point}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};