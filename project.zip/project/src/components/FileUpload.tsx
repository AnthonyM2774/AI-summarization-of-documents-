import React, { useCallback, useState } from 'react';
import { Upload, FileText, X, Scan, Database } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
  onFileRemove: () => void;
  isProcessing: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFileSelect,
  selectedFile,
  onFileRemove,
  isProcessing,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].type === 'application/pdf') {
      onFileSelect(files[0]);
    }
  }, [onFileSelect]);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onFileSelect(files[0]);
    }
  }, [onFileSelect]);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="w-full">
      <AnimatePresence mode="wait">
        {!selectedFile ? (
          <motion.div
            key="upload"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
            className={`relative group ${
              isDragOver
                ? 'bg-gradient-to-br from-cyber-900/50 to-electric-900/50 border-cyber-400'
                : 'bg-gradient-to-br from-dark-800/50 to-dark-700/50 border-dark-600 hover:border-cyber-500/50'
            } border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-500 backdrop-blur-sm`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {/* Animated background */}
            <div className="absolute inset-0 rounded-2xl overflow-hidden">
              <div className={`absolute inset-0 bg-gradient-to-r from-cyber-500/5 via-electric-500/5 to-neon-500/5 ${isDragOver ? 'animate-pulse' : ''}`}></div>
              <div className="absolute top-4 left-4 w-2 h-2 bg-cyber-400 rounded-full animate-ping"></div>
              <div className="absolute bottom-6 right-8 w-1 h-1 bg-electric-400 rounded-full animate-ping delay-1000"></div>
              <div className="absolute top-1/2 right-6 w-1.5 h-1.5 bg-neon-400 rounded-full animate-ping delay-500"></div>
            </div>

            <div className="relative flex flex-col items-center space-y-6">
              <motion.div 
                animate={{ 
                  rotate: isDragOver ? 180 : 0,
                  scale: isDragOver ? 1.1 : 1 
                }}
                transition={{ duration: 0.3 }}
                className={`relative p-6 rounded-2xl ${
                  isDragOver 
                    ? 'bg-gradient-to-br from-cyber-600 to-electric-600' 
                    : 'bg-gradient-to-br from-dark-700 to-dark-600 group-hover:from-cyber-800 group-hover:to-electric-800'
                } transition-all duration-500`}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-cyber-500/20 to-electric-500/20 rounded-2xl blur-xl"></div>
                <Upload className={`relative h-12 w-12 ${
                  isDragOver ? 'text-white' : 'text-gray-400 group-hover:text-cyber-400'
                } transition-colors duration-300`} />
              </motion.div>

              <div className="space-y-4">
                <div>
                  <h3 className="text-3xl font-black font-edgy slant-text bg-gradient-to-r from-gray-100 to-gray-300 bg-clip-text text-transparent mb-3 tracking-wider">
                    Initialize Document Scan
                  </h3>
                  <p className="text-gray-300 font-sharp text-sm leading-relaxed max-w-md slant-text tracking-wide">
                    Deploy your PDF document for neural analysis and deep content extraction
                  </p>
                </div>

                <input
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                  disabled={isProcessing}
                />
                
                <motion.label
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  htmlFor="file-upload"
                  className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-cyber-600 to-electric-600 hover:from-cyber-500 hover:to-electric-500 text-white font-bold font-edgy slant-text edgy-border shadow-2xl cursor-pointer transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed edgy-glow tracking-wider"
                >
                  <Scan className="h-5 w-5 mr-3" />
                  INITIATE SCAN PROTOCOL
                </motion.label>
              </div>

              <div className="flex items-center space-x-2 text-xs text-gray-500 font-mono">
                <Database className="h-3 w-3" />
                <span className="slant-text tracking-wider">SUPPORTS PDF • MAX 50MB • NEURAL PROCESSING READY</span>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="selected"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="relative bg-gradient-to-br from-dark-800/80 to-dark-700/80 backdrop-blur-sm border-2 border-cyber-500/40 edgy-border p-6 shadow-2xl edgy-glow"
          >
            {/* Scanning animation overlay */}
            <div className="absolute inset-0 rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cyber-500/10 to-transparent animate-scan"></div>
            </div>

            <div className="relative flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="relative"
                >
                  <div className="absolute inset-0 bg-cyber-500/30 rounded-xl blur-lg"></div>
                  <div className="relative bg-gradient-to-br from-cyber-600 to-electric-600 p-4 rounded-xl">
                    <FileText className="h-8 w-8 text-white" />
                  </div>
                </motion.div>
                
                <div className="space-y-1">
                  <h4 className="font-black text-lg text-gray-100 font-edgy slant-text tracking-wide">{selectedFile.name}</h4>
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="text-cyber-300 font-sharp slant-text tracking-wider">{formatFileSize(selectedFile.size)}</span>
                    <span className="text-gray-500">•</span>
                    <span className="text-electric-300 font-sharp slant-text tracking-wider">PDF DOCUMENT</span>
                    <span className="text-gray-500">•</span>
                    <div className="flex items-center space-x-1">
                      <div className="w-2 h-2 bg-neon-400 rounded-full animate-pulse"></div>
                      <span className="text-neon-300 font-sharp text-xs slant-text tracking-wider">READY FOR ANALYSIS</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {!isProcessing && (
                <motion.button
                  whileHover={{ scale: 1.1, rotate: 90 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onFileRemove}
                  className="p-3 edgy-border bg-dark-700 hover:bg-red-600/20 border-2 border-dark-600 hover:border-red-500/50 text-gray-400 hover:text-red-400 transition-all duration-300 edgy-glow"
                >
                  <X className="h-5 w-5" />
                </motion.button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};