import pptxgen from 'pptxgenjs';

export interface SummaryResult {
  id: string;
  model: 'bert' | 'lstm' | 'multimodel';
  title: string;
  content: string;
  confidence: number;
  processingTime: number;
  keyPoints: string[];
  domain?: string;
}

export interface ExtractedContent {
  text: string;
  imageCount: number;
  pageCount: number;
  wordCount: number;
  images: ExtractedImage[];
  domain?: string;
}

export interface ExtractedImage {
  id: string;
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  explanation?: string;
}

export interface ProcessingStep {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}

// Domain-specific theme configurations
const getDomainTheme = (domain: string) => {
  const themes = {
    academic: {
      primary: '1E3A8A',      // Deep blue
      secondary: '3B82F6',    // Blue
      accent: '60A5FA',       // Light blue
      background: 'FFFFFF',   // White
      text: '1F2937',         // Dark gray
      subtitle: '4B5563',     // Medium gray
      highlight: 'EFF6FF',    // Very light blue
      fonts: {
        title: 'Times New Roman',
        heading: 'Arial',
        body: 'Calibri'
      }
    },
    business: {
      primary: '059669',      // Emerald
      secondary: '10B981',    // Green
      accent: '34D399',       // Light green
      background: 'F9FAFB',   // Light gray
      text: '111827',         // Very dark gray
      subtitle: '374151',     // Dark gray
      highlight: 'ECFDF5',    // Very light green
      fonts: {
        title: 'Arial',
        heading: 'Arial',
        body: 'Calibri'
      }
    },
    medical: {
      primary: 'DC2626',      // Red
      secondary: 'EF4444',    // Light red
      accent: 'F87171',       // Lighter red
      background: 'FFFFFF',   // White
      text: '1F2937',         // Dark gray
      subtitle: '4B5563',     // Medium gray
      highlight: 'FEF2F2',    // Very light red
      fonts: {
        title: 'Arial',
        heading: 'Arial',
        body: 'Calibri'
      }
    },
    legal: {
      primary: '92400E',      // Dark amber
      secondary: 'D97706',    // Amber
      accent: 'F59E0B',       // Light amber
      background: 'FFFBEB',   // Very light amber
      text: '1C1917',         // Very dark brown
      subtitle: '44403C',     // Dark brown
      highlight: 'FEF3C7',    // Light amber
      fonts: {
        title: 'Times New Roman',
        heading: 'Georgia',
        body: 'Times New Roman'
      }
    },
    financial: {
      primary: '1E40AF',      // Blue
      secondary: '2563EB',    // Medium blue
      accent: '3B82F6',       // Light blue
      background: 'F8FAFC',   // Very light blue-gray
      text: '0F172A',         // Very dark blue
      subtitle: '334155',     // Dark blue-gray
      highlight: 'E0F2FE',    // Very light blue
      fonts: {
        title: 'Arial',
        heading: 'Arial',
        body: 'Calibri'
      }
    },
    technical: {
      primary: '7C3AED',      // Purple
      secondary: '8B5CF6',    // Medium purple
      accent: 'A78BFA',       // Light purple
      background: 'FAFAFA',   // Light gray
      text: '18181B',         // Very dark gray
      subtitle: '3F3F46',     // Dark gray
      highlight: 'F3F4F6',    // Light gray
      fonts: {
        title: 'Arial',
        heading: 'Arial',
        body: 'Consolas'
      }
    },
    educational: {
      primary: 'DB2777',      // Pink
      secondary: 'EC4899',    // Medium pink
      accent: 'F472B6',       // Light pink
      background: 'FFFBFF',   // Very light pink
      text: '1F2937',         // Dark gray
      subtitle: '4B5563',     // Medium gray
      highlight: 'FDF2F8',    // Very light pink
      fonts: {
        title: 'Arial',
        heading: 'Arial',
        body: 'Calibri'
      }
    },
    general: {
      primary: '374151',      // Gray
      secondary: '6B7280',    // Medium gray
      accent: '9CA3AF',       // Light gray
      background: 'FFFFFF',   // White
      text: '111827',         // Very dark gray
      subtitle: '4B5563',     // Medium gray
      highlight: 'F9FAFB',    // Very light gray
      fonts: {
        title: 'Arial',
        heading: 'Arial',
        body: 'Calibri'
      }
    }
  };
  
  return themes[domain] || themes.general;
};

// Improved text fitting and layout functions
const fitTextToBox = (text: string, maxWidth: number, fontSize: number, fontFamily: string): { 
  text: string; 
  fontSize: number; 
  lines: number 
} => {
  const avgCharWidth = fontSize * 0.6; // Approximate character width
  const maxCharsPerLine = Math.floor(maxWidth * 72 / avgCharWidth); // Convert inches to points
  
  let adjustedFontSize = fontSize;
  let lines = 1;
  
  // Calculate number of lines needed
  const words = text.split(' ');
  let currentLine = '';
  let lineCount = 0;
  
  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    if (testLine.length > maxCharsPerLine) {
      if (currentLine) {
        lineCount++;
        currentLine = word;
      } else {
        // Single word is too long, we'll need to break it or reduce font size
        lineCount++;
        currentLine = '';
      }
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) lineCount++;
  
  lines = lineCount;
  
  // Adjust font size if too many lines
  const maxLines = 8; // Maximum lines we want in a text box
  if (lines > maxLines) {
    adjustedFontSize = Math.max(8, fontSize * (maxLines / lines));
    lines = maxLines;
  }
  
  return { text, fontSize: adjustedFontSize, lines };
};

const createOptimizedTextBox = (slide: any, text: string, x: number, y: number, w: number, h: number, options: any = {}) => {
  const defaultOptions = {
    fontSize: 12,
    fontFace: 'Calibri',
    color: '1F2937',
    align: 'left',
    valign: 'top',
    wrap: true,
    margin: 0.1
  };
  
  const finalOptions = { ...defaultOptions, ...options };
  
  // Fit text to box
  const fitted = fitTextToBox(text, w - (finalOptions.margin * 2), finalOptions.fontSize, finalOptions.fontFace);
  
  // Adjust height based on number of lines
  const lineHeight = fitted.fontSize * 1.2;
  const neededHeight = (fitted.lines * lineHeight) / 72; // Convert points to inches
  const adjustedHeight = Math.min(h, Math.max(0.3, neededHeight + (finalOptions.margin * 2)));
  
  slide.addText(text, {
    x: x,
    y: y,
    w: w,
    h: adjustedHeight,
    fontSize: fitted.fontSize,
    fontFace: finalOptions.fontFace,
    color: finalOptions.color,
    align: finalOptions.align,
    valign: finalOptions.valign,
    wrap: finalOptions.wrap,
    margin: finalOptions.margin
  });
  
  return adjustedHeight;
};

export const generatePowerPoint = async (
  extractedContent: ExtractedContent,
  summaryResults: SummaryResult[],
  fileName: string
): Promise<void> => {
  const pres = new pptxgen();
  const domain = extractedContent.domain || 'general';
  const theme = getDomainTheme(domain);

  // Configure presentation settings
  pres.layout = 'LAYOUT_WIDE';
  pres.defineLayout({ name: 'CUSTOM', width: 13.33, height: 7.5 });

  // Set default fonts for the presentation
  pres.defineSlideMaster({
    title: 'MASTER_SLIDE',
    background: { fill: theme.background },
    objects: [
      {
        text: {
          text: 'Title Placeholder',
          options: {
            x: 0.5, y: 0.5, w: 12.33, h: 1,
            fontSize: 28,
            fontFace: theme.fonts.title,
            color: theme.primary,
            bold: true
          }
        }
      }
    ]
  });

  // Extract comprehensive document information
  const documentTitle = extractDocumentTitle(extractedContent.text, fileName);
  const domainPrefix = getDomainPrefix(extractedContent.domain);
  const documentSections = extractDocumentSections(extractedContent.text);
  const keyTopics = extractKeyTopics(extractedContent.text, extractedContent.domain);
  const concepts = extractDetailedConcepts(extractedContent.text, extractedContent.domain);
  const methodologies = extractMethodologies(extractedContent.text, extractedContent.domain);
  const dataInsights = extractDataInsights(extractedContent.text);

  // 1. Title Slide with domain-specific design
  const titleSlide = pres.addSlide();
  titleSlide.background = { fill: theme.background };
  
  // Add domain-specific header bar
  titleSlide.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: 13.33, h: 0.5,
    fill: { color: theme.primary }
  });
  
  // Main title with proper spacing
  createOptimizedTextBox(titleSlide, documentTitle, 1, 1.5, 11.33, 2, {
    fontSize: 32,
    fontFace: theme.fonts.title,
    color: theme.primary,
    align: 'center',
    bold: true
  });
  
  // Subtitle
  createOptimizedTextBox(titleSlide, 'Comprehensive Document Analysis', 1, 3.2, 11.33, 0.8, {
    fontSize: 18,
    fontFace: theme.fonts.heading,
    color: theme.secondary,
    align: 'center'
  });

  // Document info with better spacing
  createOptimizedTextBox(titleSlide, `${domainPrefix} • ${extractedContent.pageCount} Pages • ${extractedContent.wordCount.toLocaleString()} Words`, 1, 4.2, 11.33, 0.6, {
    fontSize: 14,
    fontFace: theme.fonts.body,
    color: theme.subtitle,
    align: 'center'
  });

  // Source info
  createOptimizedTextBox(titleSlide, `Source: ${fileName}`, 1, 5, 11.33, 0.4, {
    fontSize: 12,
    fontFace: theme.fonts.body,
    color: theme.subtitle,
    align: 'center',
    italic: true
  });

  // Add domain-specific footer
  titleSlide.addShape(pres.ShapeType.rect, {
    x: 0, y: 7, w: 13.33, h: 0.5,
    fill: { color: theme.accent }
  });

  // 2. Document Overview with improved layout
  const overviewSlide = pres.addSlide();
  overviewSlide.background = { fill: theme.background };
  
  // Header
  overviewSlide.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: 13.33, h: 0.8,
    fill: { color: theme.highlight }
  });
  
  createOptimizedTextBox(overviewSlide, 'Document Overview', 0.5, 0.1, 12.33, 0.6, {
    fontSize: 24,
    fontFace: theme.fonts.title,
    color: theme.primary,
    bold: true,
    valign: 'middle'
  });

  const overviewContent = generateDocumentOverview(extractedContent, documentSections);
  createOptimizedTextBox(overviewSlide, overviewContent, 0.5, 1.2, 12.33, 5.8, {
    fontSize: 13,
    fontFace: theme.fonts.body,
    color: theme.text,
    margin: 0.2
  });

  // 3. Document Structure with better organization
  const structureSlide = pres.addSlide();
  structureSlide.background = { fill: theme.background };
  
  // Header
  structureSlide.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: 13.33, h: 0.8,
    fill: { color: theme.highlight }
  });
  
  createOptimizedTextBox(structureSlide, 'Document Structure & Organization', 0.5, 0.1, 12.33, 0.6, {
    fontSize: 22,
    fontFace: theme.fonts.title,
    color: theme.primary,
    bold: true,
    valign: 'middle'
  });

  if (documentSections.length > 0) {
    createOptimizedTextBox(structureSlide, 'Main Sections:', 0.5, 1.2, 12.33, 0.4, {
      fontSize: 16,
      fontFace: theme.fonts.heading,
      color: theme.secondary,
      bold: true
    });

    const sectionsPerSlide = 10;
    const sectionsToShow = documentSections.slice(0, sectionsPerSlide);
    
    let currentY = 1.8;
    sectionsToShow.forEach((section, index) => {
      const sectionHeight = createOptimizedTextBox(structureSlide, `${index + 1}. ${section}`, 0.8, currentY, 11.53, 0.5, {
        fontSize: 12,
        fontFace: theme.fonts.body,
        color: theme.text
      });
      currentY += Math.max(0.35, sectionHeight + 0.1);
    });

    // Create additional slides for remaining sections with consistent styling
    if (documentSections.length > sectionsPerSlide) {
      let remainingSections = documentSections.slice(sectionsPerSlide);
      let slideIndex = 2;
      
      while (remainingSections.length > 0) {
        const additionalStructureSlide = pres.addSlide();
        additionalStructureSlide.background = { fill: theme.background };
        
        // Header
        additionalStructureSlide.addShape(pres.ShapeType.rect, {
          x: 0, y: 0, w: 13.33, h: 0.8,
          fill: { color: theme.highlight }
        });
        
        createOptimizedTextBox(additionalStructureSlide, `Document Structure (Part ${slideIndex})`, 0.5, 0.1, 12.33, 0.6, {
          fontSize: 22,
          fontFace: theme.fonts.title,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        const currentBatch = remainingSections.slice(0, sectionsPerSlide);
        let currentY = 1.2;
        currentBatch.forEach((section, index) => {
          const sectionHeight = createOptimizedTextBox(additionalStructureSlide, `${sectionsPerSlide * (slideIndex - 1) + index + 1}. ${section}`, 0.8, currentY, 11.53, 0.5, {
            fontSize: 12,
            fontFace: theme.fonts.body,
            color: theme.text
          });
          currentY += Math.max(0.35, sectionHeight + 0.1);
        });

        remainingSections = remainingSections.slice(sectionsPerSlide);
        slideIndex++;
      }
    }
  }

  // 4-N. Key Topics & Concepts with improved layout
  if (keyTopics.length > 0) {
    const topicsPerSlide = 2; // Reduced for better spacing
    let topicSlideIndex = 1;
    
    for (let i = 0; i < keyTopics.length; i += topicsPerSlide) {
      const topicsSlide = pres.addSlide();
      topicsSlide.background = { fill: theme.background };
      
      // Header
      topicsSlide.addShape(pres.ShapeType.rect, {
        x: 0, y: 0, w: 13.33, h: 0.8,
        fill: { color: theme.highlight }
      });
      
      const slideTitle = keyTopics.length > topicsPerSlide ? 
        `Key Topics & Concepts (Part ${topicSlideIndex})` : 
        'Key Topics & Concepts';
      
      createOptimizedTextBox(topicsSlide, slideTitle, 0.5, 0.1, 12.33, 0.6, {
        fontSize: 22,
        fontFace: theme.fonts.title,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      const currentTopics = keyTopics.slice(i, i + topicsPerSlide);
      let currentY = 1.2;
      
      currentTopics.forEach((topic, index) => {
        // Topic title with background
        topicsSlide.addShape(pres.ShapeType.rect, {
          x: 0.5, y: currentY, w: 12.33, h: 0.6,
          fill: { color: theme.accent, transparency: 80 }
        });
        
        createOptimizedTextBox(topicsSlide, topic.title, 0.7, currentY + 0.05, 11.93, 0.5, {
          fontSize: 16,
          fontFace: theme.fonts.heading,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        currentY += 0.8;
        
        const descHeight = createOptimizedTextBox(topicsSlide, topic.description, 0.8, currentY, 11.53, 2.5, {
          fontSize: 12,
          fontFace: theme.fonts.body,
          color: theme.text,
          margin: 0.15
        });
        
        currentY += Math.max(1.5, descHeight + 0.3);
      });
      
      topicSlideIndex++;
    }
  }

  // Enhanced Concepts with better spacing
  if (concepts.length > 0) {
    concepts.forEach((concept, index) => {
      const conceptSlide = pres.addSlide();
      conceptSlide.background = { fill: theme.background };
      
      // Header
      conceptSlide.addShape(pres.ShapeType.rect, {
        x: 0, y: 0, w: 13.33, h: 0.8,
        fill: { color: theme.highlight }
      });
      
      createOptimizedTextBox(conceptSlide, `Concept: ${concept.title}`, 0.5, 0.1, 12.33, 0.6, {
        fontSize: 20,
        fontFace: theme.fonts.title,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      let currentY = 1.2;

      // Definition section
      conceptSlide.addShape(pres.ShapeType.rect, {
        x: 0.5, y: currentY, w: 12.33, h: 0.4,
        fill: { color: theme.secondary, transparency: 90 }
      });
      
      createOptimizedTextBox(conceptSlide, 'Definition & Overview:', 0.7, currentY + 0.05, 11.93, 0.3, {
        fontSize: 14,
        fontFace: theme.fonts.heading,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      currentY += 0.5;
      
      const defHeight = createOptimizedTextBox(conceptSlide, concept.definition, 0.5, currentY, 12.33, 2, {
        fontSize: 12,
        fontFace: theme.fonts.body,
        color: theme.text,
        margin: 0.15
      });

      currentY += Math.max(1.2, defHeight + 0.2);

      // Applications section
      if (concept.applications.length > 0) {
        conceptSlide.addShape(pres.ShapeType.rect, {
          x: 0.5, y: currentY, w: 12.33, h: 0.4,
          fill: { color: theme.secondary, transparency: 90 }
        });
        
        createOptimizedTextBox(conceptSlide, 'Applications & Examples:', 0.7, currentY + 0.05, 11.93, 0.3, {
          fontSize: 14,
          fontFace: theme.fonts.heading,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        currentY += 0.5;

        concept.applications.slice(0, 4).forEach((app, appIndex) => {
          const appHeight = createOptimizedTextBox(conceptSlide, `• ${app}`, 0.8, currentY, 11.53, 0.6, {
            fontSize: 11,
            fontFace: theme.fonts.body,
            color: theme.text
          });
          currentY += Math.max(0.3, appHeight + 0.1);
        });
      }

      // Significance section
      if (concept.significance && currentY < 6.5) {
        conceptSlide.addShape(pres.ShapeType.rect, {
          x: 0.5, y: currentY, w: 12.33, h: 0.4,
          fill: { color: theme.secondary, transparency: 90 }
        });
        
        createOptimizedTextBox(conceptSlide, 'Significance:', 0.7, currentY + 0.05, 11.93, 0.3, {
          fontSize: 14,
          fontFace: theme.fonts.heading,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        currentY += 0.5;

        createOptimizedTextBox(conceptSlide, concept.significance, 0.5, currentY, 12.33, 7.5 - currentY - 0.2, {
          fontSize: 11,
          fontFace: theme.fonts.body,
          color: theme.text,
          margin: 0.15
        });
      }
    });
  }

  // Methodologies & Approaches
  if (methodologies.length > 0) {
    methodologies.forEach((methodology) => {
      const methodSlide = pres.addSlide();
      methodSlide.background = { fill: theme.background };
      
      // Header
      methodSlide.addShape(pres.ShapeType.rect, {
        x: 0, y: 0, w: 13.33, h: 0.8,
        fill: { color: theme.highlight }
      });
      
      createOptimizedTextBox(methodSlide, `Methodology: ${methodology.title}`, 0.5, 0.1, 12.33, 0.6, {
        fontSize: 20,
        fontFace: theme.fonts.title,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      let currentY = 1.2;

      // Approach section
      methodSlide.addShape(pres.ShapeType.rect, {
        x: 0.5, y: currentY, w: 12.33, h: 0.4,
        fill: { color: theme.secondary, transparency: 90 }
      });
      
      createOptimizedTextBox(methodSlide, 'Approach & Process:', 0.7, currentY + 0.05, 11.93, 0.3, {
        fontSize: 14,
        fontFace: theme.fonts.heading,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      currentY += 0.5;

      const descHeight = createOptimizedTextBox(methodSlide, methodology.description, 0.5, currentY, 12.33, 2, {
        fontSize: 12,
        fontFace: theme.fonts.body,
        color: theme.text,
        margin: 0.15
      });

      currentY += Math.max(1.5, descHeight + 0.2);

      if (methodology.steps.length > 0) {
        methodSlide.addShape(pres.ShapeType.rect, {
          x: 0.5, y: currentY, w: 12.33, h: 0.4,
          fill: { color: theme.secondary, transparency: 90 }
        });
        
        createOptimizedTextBox(methodSlide, 'Key Steps:', 0.7, currentY + 0.05, 11.93, 0.3, {
          fontSize: 14,
          fontFace: theme.fonts.heading,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        currentY += 0.5;

        methodology.steps.forEach((step, stepIndex) => {
          const stepHeight = createOptimizedTextBox(methodSlide, `${stepIndex + 1}. ${step}`, 0.8, currentY, 11.53, 0.5, {
            fontSize: 11,
            fontFace: theme.fonts.body,
            color: theme.text
          });
          currentY += Math.max(0.3, stepHeight + 0.1);
        });
      }
    });
  }

  // Enhanced Visual Content Analysis with domain-specific styling
  if (extractedContent.images && extractedContent.images.length > 0) {
    // Visual Content Overview
    const visualOverviewSlide = pres.addSlide();
    visualOverviewSlide.background = { fill: theme.background };
    
    // Header
    visualOverviewSlide.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: 13.33, h: 0.8,
      fill: { color: theme.highlight }
    });
    
    createOptimizedTextBox(visualOverviewSlide, 'Visual Content Overview', 0.5, 0.1, 12.33, 0.6, {
      fontSize: 22,
      fontFace: theme.fonts.title,
      color: theme.primary,
      bold: true,
      valign: 'middle'
    });

    const visualSummary = generateEnhancedVisualSummary(extractedContent.images, extractedContent.domain);
    createOptimizedTextBox(visualOverviewSlide, visualSummary, 0.5, 1.2, 12.33, 5.8, {
      fontSize: 12,
      fontFace: theme.fonts.body,
      color: theme.text,
      margin: 0.2
    });

    // Individual detailed slides for each visual element
    extractedContent.images.forEach((image, index) => {
      const imageSlide = pres.addSlide();
      imageSlide.background = { fill: theme.background };
      
      // Header
      imageSlide.addShape(pres.ShapeType.rect, {
        x: 0, y: 0, w: 13.33, h: 0.8,
        fill: { color: theme.highlight }
      });
      
      createOptimizedTextBox(imageSlide, `Visual Analysis: Figure ${index + 1} (Page ${image.pageNumber})`, 0.5, 0.1, 12.33, 0.6, {
        fontSize: 18,
        fontFace: theme.fonts.title,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      // Add the actual image with proper sizing
      try {
        imageSlide.addImage({
          data: image.dataUrl,
          x: 0.5,
          y: 1,
          w: 6,
          h: 4.5,
          sizing: { type: 'contain', w: 6, h: 4.5 }
        });
      } catch (error) {
        console.warn(`Could not add image ${image.id} to slide:`, error);
        imageSlide.addShape(pres.ShapeType.rect, {
          x: 0.5, y: 1, w: 6, h: 4.5,
          fill: { color: theme.highlight },
          line: { color: theme.accent, width: 2 }
        });
        createOptimizedTextBox(imageSlide, 'Visual Element from Document\n(Image could not be embedded)', 0.5, 2.5, 6, 1, {
          fontSize: 12,
          fontFace: theme.fonts.body,
          color: theme.subtitle,
          align: 'center',
          italic: true,
          valign: 'middle'
        });
      }

      // Enhanced detailed analysis with better layout
      const detailedAnalysis = generateDetailedImageAnalysis(image, extractedContent.text, extractedContent.domain);
      
      let rightColumnY = 1;
      
      // Description section
      imageSlide.addShape(pres.ShapeType.rect, {
        x: 7, y: rightColumnY, w: 5.83, h: 0.3,
        fill: { color: theme.accent, transparency: 80 }
      });
      
      createOptimizedTextBox(imageSlide, 'Visual Content Description:', 7.1, rightColumnY + 0.05, 5.63, 0.2, {
        fontSize: 12,
        fontFace: theme.fonts.heading,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      rightColumnY += 0.4;
      
      const descHeight = createOptimizedTextBox(imageSlide, detailedAnalysis.description, 7, rightColumnY, 5.83, 1.5, {
        fontSize: 10,
        fontFace: theme.fonts.body,
        color: theme.text,
        margin: 0.1
      });

      rightColumnY += Math.max(1, descHeight + 0.2);

      // Technical details section
      imageSlide.addShape(pres.ShapeType.rect, {
        x: 7, y: rightColumnY, w: 5.83, h: 0.3,
        fill: { color: theme.accent, transparency: 80 }
      });
      
      createOptimizedTextBox(imageSlide, 'Technical Details:', 7.1, rightColumnY + 0.05, 5.63, 0.2, {
        fontSize: 12,
        fontFace: theme.fonts.heading,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      rightColumnY += 0.4;
      
      const techHeight = createOptimizedTextBox(imageSlide, detailedAnalysis.technical, 7, rightColumnY, 5.83, 1, {
        fontSize: 10,
        fontFace: theme.fonts.body,
        color: theme.text,
        margin: 0.1
      });

      rightColumnY += Math.max(0.8, techHeight + 0.2);

      // Significance section
      if (rightColumnY < 5.5) {
        imageSlide.addShape(pres.ShapeType.rect, {
          x: 7, y: rightColumnY, w: 5.83, h: 0.3,
          fill: { color: theme.accent, transparency: 80 }
        });
        
        createOptimizedTextBox(imageSlide, 'Context & Significance:', 7.1, rightColumnY + 0.05, 5.63, 0.2, {
          fontSize: 12,
          fontFace: theme.fonts.heading,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        rightColumnY += 0.4;

        createOptimizedTextBox(imageSlide, detailedAnalysis.significance, 7, rightColumnY, 5.83, 5.5 - rightColumnY, {
          fontSize: 10,
          fontFace: theme.fonts.body,
          color: theme.text,
          margin: 0.1
        });
      }

      // Document context at bottom
      createOptimizedTextBox(imageSlide, `Document Integration: ${detailedAnalysis.context}`, 0.5, 5.8, 12.33, 1.4, {
        fontSize: 10,
        fontFace: theme.fonts.body,
        color: theme.subtitle,
        margin: 0.15
      });
    });
  }

  // Data & Statistics Analysis (Multiple slides if needed)
  if (dataInsights.length > 0) {
    const dataSlide = pres.addSlide();
    dataSlide.background = { fill: theme.background };
    
    // Header
    dataSlide.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: 13.33, h: 0.8,
      fill: { color: theme.highlight }
    });
    
    createOptimizedTextBox(dataSlide, 'Data & Statistical Information', 0.5, 0.1, 12.33, 0.6, {
      fontSize: 22,
      fontFace: theme.fonts.title,
      color: theme.primary,
      bold: true,
      valign: 'middle'
    });

    const insightsPerSlide = 8;
    const currentInsights = dataInsights.slice(0, insightsPerSlide);
    
    let currentY = 1.3;
    currentInsights.forEach((insight, index) => {
      const insightHeight = createOptimizedTextBox(dataSlide, `• ${insight}`, 0.8, currentY, 11.53, 0.6, {
        fontSize: 12,
        fontFace: theme.fonts.body,
        color: theme.text,
        margin: 0.1
      });
      currentY += Math.max(0.5, insightHeight + 0.1);
    });

    // Additional data slides if needed
    if (dataInsights.length > insightsPerSlide) {
      let remainingInsights = dataInsights.slice(insightsPerSlide);
      let dataSlideIndex = 2;
      
      while (remainingInsights.length > 0) {
        const additionalDataSlide = pres.addSlide();
        additionalDataSlide.background = { fill: theme.background };
        
        // Header
        additionalDataSlide.addShape(pres.ShapeType.rect, {
          x: 0, y: 0, w: 13.33, h: 0.8,
          fill: { color: theme.highlight }
        });
        
        createOptimizedTextBox(additionalDataSlide, `Data & Statistics (Part ${dataSlideIndex})`, 0.5, 0.1, 12.33, 0.6, {
          fontSize: 22,
          fontFace: theme.fonts.title,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        const currentBatch = remainingInsights.slice(0, insightsPerSlide);
        let currentY = 1.3;
        currentBatch.forEach((insight, index) => {
          const insightHeight = createOptimizedTextBox(additionalDataSlide, `• ${insight}`, 0.8, currentY, 11.53, 0.6, {
            fontSize: 12,
            fontFace: theme.fonts.body,
            color: theme.text,
            margin: 0.1
          });
          currentY += Math.max(0.5, insightHeight + 0.1);
        });

        remainingInsights = remainingInsights.slice(insightsPerSlide);
        dataSlideIndex++;
      }
    }
  }

  // Enhanced Content Analysis slides with better spacing
  const contentAnalysisSlides = generateDetailedContentSlides(extractedContent, summaryResults);
  contentAnalysisSlides.forEach(slideContent => {
    const slide = pres.addSlide();
    slide.background = { fill: theme.background };
    
    // Header
    slide.addShape(pres.ShapeType.rect, {
      x: 0, y: 0, w: 13.33, h: 0.8,
      fill: { color: theme.highlight }
    });
    
    createOptimizedTextBox(slide, slideContent.title, 0.5, 0.1, 12.33, 0.6, {
      fontSize: 20,
      fontFace: theme.fonts.title,
      color: theme.primary,
      bold: true,
      valign: 'middle'
    });

    const contentHeight = createOptimizedTextBox(slide, slideContent.content, 0.5, 1.2, 12.33, 4, {
      fontSize: 12,
      fontFace: theme.fonts.body,
      color: theme.text,
      margin: 0.2
    });

    if (slideContent.keyPoints && slideContent.keyPoints.length > 0) {
      const keyPointsY = Math.min(5.4, 1.2 + contentHeight + 0.3);
      
      slide.addShape(pres.ShapeType.rect, {
        x: 0.5, y: keyPointsY, w: 12.33, h: 0.3,
        fill: { color: theme.accent, transparency: 80 }
      });
      
      createOptimizedTextBox(slide, 'Key Points:', 0.7, keyPointsY + 0.05, 11.93, 0.2, {
        fontSize: 12,
        fontFace: theme.fonts.heading,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      let currentY = keyPointsY + 0.4;
      slideContent.keyPoints.slice(0, 4).forEach((point, pointIndex) => {
        const pointHeight = createOptimizedTextBox(slide, `• ${point}`, 0.8, currentY, 11.53, 0.4, {
          fontSize: 10,
          fontFace: theme.fonts.body,
          color: theme.subtitle
        });
        currentY += Math.max(0.25, pointHeight + 0.05);
      });
    }
  });

  // Conclusions & Key Findings (Multiple slides)
  const conclusions = extractDetailedConclusions(extractedContent.text, summaryResults);
  if (conclusions.length > 0) {
    conclusions.forEach((conclusion, index) => {
      const conclusionSlide = pres.addSlide();
      conclusionSlide.background = { fill: theme.background };
      
      // Header
      conclusionSlide.addShape(pres.ShapeType.rect, {
        x: 0, y: 0, w: 13.33, h: 0.8,
        fill: { color: theme.highlight }
      });
      
      createOptimizedTextBox(conclusionSlide, `Key Finding ${index + 1}: ${conclusion.title}`, 0.5, 0.1, 12.33, 0.6, {
        fontSize: 20,
        fontFace: theme.fonts.title,
        color: theme.primary,
        bold: true,
        valign: 'middle'
      });

      const contentHeight = createOptimizedTextBox(conclusionSlide, conclusion.content, 0.5, 1.2, 12.33, 4, {
        fontSize: 12,
        fontFace: theme.fonts.body,
        color: theme.text,
        margin: 0.2
      });

      if (conclusion.implications.length > 0) {
        const implicationsY = Math.min(5.4, 1.2 + contentHeight + 0.3);
        
        conclusionSlide.addShape(pres.ShapeType.rect, {
          x: 0.5, y: implicationsY, w: 12.33, h: 0.3,
          fill: { color: theme.secondary, transparency: 90 }
        });
        
        createOptimizedTextBox(conclusionSlide, 'Implications:', 0.7, implicationsY + 0.05, 11.93, 0.2, {
          fontSize: 12,
          fontFace: theme.fonts.heading,
          color: theme.primary,
          bold: true,
          valign: 'middle'
        });

        let currentY = implicationsY + 0.4;
        conclusion.implications.forEach((implication, impIndex) => {
          const impHeight = createOptimizedTextBox(conclusionSlide, `• ${implication}`, 0.8, currentY, 11.53, 0.4, {
            fontSize: 10,
            fontFace: theme.fonts.body,
            color: theme.text
          });
          currentY += Math.max(0.25, impHeight + 0.05);
        });
      }
    });
  }

  // Final Summary with enhanced design
  const summarySlide = pres.addSlide();
  summarySlide.background = { fill: theme.background };
  
  // Header
  summarySlide.addShape(pres.ShapeType.rect, {
    x: 0, y: 0, w: 13.33, h: 0.8,
    fill: { color: theme.highlight }
  });
  
  createOptimizedTextBox(summarySlide, 'Document Summary & Conclusions', 0.5, 0.1, 12.33, 0.6, {
    fontSize: 22,
    fontFace: theme.fonts.title,
    color: theme.primary,
    bold: true,
    valign: 'middle'
  });

  const finalSummary = generateComprehensiveDocumentSummary(extractedContent, summaryResults);
  createOptimizedTextBox(summarySlide, finalSummary, 0.5, 1.2, 12.33, 5.8, {
    fontSize: 12,
    fontFace: theme.fonts.body,
    color: theme.text,
    margin: 0.2
  });

  // Add footer to summary slide
  summarySlide.addShape(pres.ShapeType.rect, {
    x: 0, y: 7, w: 13.33, h: 0.5,
    fill: { color: theme.primary }
  });

  createOptimizedTextBox(summarySlide, `Generated by Neural Document Intelligence System • ${new Date().toLocaleDateString()}`, 0.5, 7.1, 12.33, 0.3, {
    fontSize: 10,
    fontFace: theme.fonts.body,
    color: 'FFFFFF',
    align: 'center',
    valign: 'middle'
  });

  // Generate and download with domain-specific naming
  const presentationName = `${documentTitle.replace(/[^a-zA-Z0-9]/g, '_')}_${domain.toUpperCase()}_Analysis.pptx`;
  await pres.writeFile({ fileName: presentationName });
};

// Helper functions remain the same but with improved text handling
function extractDocumentTitle(text: string, fileName: string): string {
  const lines = text.split('\n').filter(line => line.trim().length > 0);
  
  for (let i = 0; i < Math.min(15, lines.length); i++) {
    const line = lines[i].trim();
    if (line.length > 10 && line.length < 200 && 
        !line.includes('http') && 
        !line.includes('@') &&
        !/^\d+\./.test(line) &&
        !/^page \d+/i.test(line) &&
        !/^chapter \d+/i.test(line)) {
      return line;
    }
  }
  
  return fileName.replace(/\.[^/.]+$/, '');
}

function getDomainPrefix(domain?: string): string {
  const prefixes: Record<string, string> = {
    academic: 'Academic Research',
    business: 'Business Analysis',
    medical: 'Medical Documentation',
    legal: 'Legal Documentation',
    financial: 'Financial Analysis',
    technical: 'Technical Documentation',
    educational: 'Educational Content'
  };
  
  return prefixes[domain || 'general'] || 'Professional Document';
}

function extractDocumentSections(text: string): string[] {
  const sections: string[] = [];
  
  // Enhanced section detection
  const numberedSections = text.match(/^\d+\.?\s+[A-Z][^.\n]{10,150}/gm);
  if (numberedSections) {
    sections.push(...numberedSections.map(s => s.replace(/^\d+\.?\s+/, '').trim()));
  }
  
  const headings = text.match(/^[A-Z][A-Z\s]{5,80}$/gm);
  if (headings) {
    sections.push(...headings.map(h => h.trim()));
  }
  
  const bulletSections = text.match(/^[•\-\*]\s+[A-Z][^.\n]{10,100}/gm);
  if (bulletSections) {
    sections.push(...bulletSections.map(s => s.replace(/^[•\-\*]\s+/, '').trim()));
  }
  
  return [...new Set(sections)].slice(0, 20);
}

function extractKeyTopics(text: string, domain?: string): Array<{title: string; description: string}> {
  const topics: Array<{title: string; description: string}> = [];
  
  const domainKeywords: Record<string, string[]> = {
    academic: ['research', 'methodology', 'analysis', 'findings', 'conclusion', 'hypothesis', 'study', 'data', 'theory', 'framework'],
    business: ['strategy', 'market', 'revenue', 'growth', 'performance', 'objectives', 'analysis', 'recommendations', 'competitive', 'operations'],
    medical: ['patient', 'treatment', 'diagnosis', 'clinical', 'symptoms', 'therapy', 'medical', 'health', 'disease', 'care'],
    legal: ['contract', 'agreement', 'legal', 'clause', 'terms', 'liability', 'compliance', 'regulation', 'rights', 'obligations'],
    financial: ['financial', 'revenue', 'profit', 'investment', 'cost', 'budget', 'analysis', 'performance', 'risk', 'return'],
    technical: ['system', 'process', 'implementation', 'technical', 'specification', 'requirements', 'design', 'architecture', 'development'],
    educational: ['learning', 'education', 'student', 'curriculum', 'assessment', 'knowledge', 'skills', 'teaching', 'instruction']
  };
  
  const keywords = domainKeywords[domain || 'general'] || ['information', 'content', 'data', 'analysis', 'overview', 'process', 'system', 'approach'];
  
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 80);
  
  keywords.forEach(keyword => {
    const relevantSentences = sentences.filter(s => 
      s.toLowerCase().includes(keyword.toLowerCase())
    );
    
    if (relevantSentences.length > 0) {
      const bestSentence = relevantSentences.sort((a, b) => b.length - a.length)[0];
      topics.push({
        title: keyword.charAt(0).toUpperCase() + keyword.slice(1) + ' Overview',
        description: bestSentence.trim().substring(0, 400) + (bestSentence.length > 400 ? '...' : '')
      });
    }
  });
  
  return topics.slice(0, 8);
}

function extractDetailedConcepts(text: string, domain?: string): Array<{
  title: string;
  definition: string;
  applications: string[];
  significance: string;
}> {
  const concepts: Array<{title: string; definition: string; applications: string[]; significance: string}> = [];
  
  // Look for definition patterns
  const definitionPatterns = [
    /([A-Z][a-zA-Z\s]{5,50})\s+is\s+defined\s+as\s+([^.]{20,200})/g,
    /([A-Z][a-zA-Z\s]{5,50})\s+refers\s+to\s+([^.]{20,200})/g,
    /([A-Z][a-zA-Z\s]{5,50})\s+means\s+([^.]{20,200})/g,
    /The\s+concept\s+of\s+([A-Z][a-zA-Z\s]{5,50})\s+([^.]{20,200})/g
  ];
  
  definitionPatterns.forEach(pattern => {
    let match;
    while ((match = pattern.exec(text)) !== null && concepts.length < 5) {
      const title = match[1].trim();
      const definition = match[2].trim();
      
      // Find applications
      const applications = findApplications(text, title);
      const significance = findSignificance(text, title);
      
      concepts.push({
        title,
        definition,
        applications,
        significance
      });
    }
  });
  
  return concepts;
}

function findApplications(text: string, concept: string): string[] {
  const applications: string[] = [];
  const sentences = text.split(/[.!?]+/);
  
  sentences.forEach(sentence => {
    if (sentence.toLowerCase().includes(concept.toLowerCase()) && 
        (sentence.toLowerCase().includes('application') || 
         sentence.toLowerCase().includes('used for') ||
         sentence.toLowerCase().includes('example'))) {
      applications.push(sentence.trim());
    }
  });
  
  return applications.slice(0, 3);
}

function findSignificance(text: string, concept: string): string {
  const sentences = text.split(/[.!?]+/);
  
  for (const sentence of sentences) {
    if (sentence.toLowerCase().includes(concept.toLowerCase()) && 
        (sentence.toLowerCase().includes('important') || 
         sentence.toLowerCase().includes('significant') ||
         sentence.toLowerCase().includes('crucial') ||
         sentence.toLowerCase().includes('essential'))) {
      return sentence.trim();
    }
  }
  
  return `${concept} plays a crucial role in the overall context of this document and contributes to the comprehensive understanding of the subject matter.`;
}

function extractMethodologies(text: string, domain?: string): Array<{
  title: string;
  description: string;
  steps: string[];
}> {
  const methodologies: Array<{title: string; description: string; steps: string[]}> = [];
  
  // Look for methodology patterns
  const methodPatterns = [
    /methodology|approach|method|process|procedure|technique|framework/gi
  ];
  
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 50);
  
  sentences.forEach(sentence => {
    methodPatterns.forEach(pattern => {
      if (pattern.test(sentence)) {
        const steps = extractSteps(text, sentence);
        if (steps.length > 0) {
          methodologies.push({
            title: extractMethodTitle(sentence),
            description: sentence.trim(),
            steps
          });
        }
      }
    });
  });
  
  return methodologies.slice(0, 3);
}

function extractSteps(text: string, methodSentence: string): string[] {
  const steps: string[] = [];
  
  // Look for numbered steps
  const numberedSteps = text.match(/\d+\.\s+[^.\n]{20,150}/g);
  if (numberedSteps) {
    steps.push(...numberedSteps.map(step => step.replace(/^\d+\.\s+/, '').trim()));
  }
  
  // Look for bullet points
  const bulletSteps = text.match(/[•\-\*]\s+[^.\n]{20,150}/g);
  if (bulletSteps) {
    steps.push(...bulletSteps.map(step => step.replace(/^[•\-\*]\s+/, '').trim()));
  }
  
  return steps.slice(0, 6);
}

function extractMethodTitle(sentence: string): string {
  const words = sentence.split(' ');
  const methodWords = words.filter(word => 
    /methodology|approach|method|process|procedure|technique|framework/i.test(word)
  );
  
  if (methodWords.length > 0) {
    const index = words.indexOf(methodWords[0]);
    const title = words.slice(Math.max(0, index - 2), index + 3).join(' ');
    return title.charAt(0).toUpperCase() + title.slice(1);
  }
  
  return 'Document Methodology';
}

function generateDocumentOverview(extractedContent: ExtractedContent, sections: string[]): string {
  const domain = extractedContent.domain || 'general';
  const readingTime = Math.ceil(extractedContent.wordCount / 200);
  
  return `This comprehensive ${domain} document presents detailed information across ${extractedContent.pageCount} pages, containing ${extractedContent.wordCount.toLocaleString()} words with an estimated reading time of ${readingTime} minutes.

DOCUMENT SCOPE & COVERAGE:
The document provides ${extractedContent.wordCount > 10000 ? 'extensive and thorough' : extractedContent.wordCount > 5000 ? 'comprehensive' : 'focused'} coverage of its subject matter, demonstrating ${domain === 'academic' ? 'scholarly rigor and research-based methodology' : domain === 'business' ? 'strategic analysis and professional insights' : domain === 'technical' ? 'technical precision and systematic documentation' : 'professional standards and structured presentation'}.

VISUAL CONTENT INTEGRATION:
${extractedContent.imageCount > 0 ? 
  `The document incorporates ${extractedContent.imageCount} visual elements including charts, diagrams, tables, and illustrations that enhance understanding and provide supporting evidence for the textual content. These visuals are strategically distributed across ${new Set(extractedContent.images.map(img => img.pageNumber)).size} pages to maximize comprehension and engagement.` : 
  'The document maintains a text-focused approach with clear narrative structure and logical information flow, relying on comprehensive written explanations to convey complex concepts.'
}

STRUCTURAL ORGANIZATION:
${sections.length > 0 ? 
  `The document demonstrates excellent organizational structure with ${sections.length} clearly defined sections, ensuring logical progression of ideas and facilitating easy navigation through complex topics.` : 
  'The document follows a coherent organizational framework with well-structured content blocks that guide readers through the material systematically.'
}

This document serves as a valuable resource for understanding ${domain} concepts and provides practical insights that can be applied in relevant professional or academic contexts.`;
}

function generateEnhancedVisualSummary(images: ExtractedImage[], domain?: string): string {
  const imageTypes = analyzeImageTypes(images);
  const pageDistribution = new Set(images.map(img => img.pageNumber)).size;
  
  return `VISUAL CONTENT ANALYSIS OVERVIEW

This document contains ${images.length} visual elements strategically distributed across ${pageDistribution} pages, representing approximately ${((images.length / pageDistribution) * 100).toFixed(1)}% visual content integration.

VISUAL ELEMENT BREAKDOWN:
${imageTypes.map(type => `• ${type.count} ${type.type}(s): ${type.description}`).join('\n')}

CONTENT DISTRIBUTION:
The visual elements are positioned throughout the document to support key arguments, illustrate complex concepts, and provide empirical evidence. Each visual component has been analyzed for:
- Content type and format
- Technical specifications and quality
- Contextual relevance to surrounding text
- Educational or informational value
- Integration with document narrative

DOMAIN-SPECIFIC RELEVANCE:
${domain ? `These visual elements are specifically tailored to ${domain} content standards, incorporating specialized visualizations, data presentations, and illustrative materials typical of professional ${domain} documentation.` : 'The visual elements demonstrate professional quality and are appropriately integrated to enhance document comprehension.'}

Each visual element will be analyzed individually in the following slides to provide comprehensive understanding of their content, significance, and contribution to the overall document narrative.`;
}

function analyzeImageTypes(images: ExtractedImage[]): Array<{type: string; count: number; description: string}> {
  const types: Array<{type: string; count: number; description: string}> = [];
  
  let charts = 0, diagrams = 0, tables = 0, photos = 0, mixed = 0;
  
  images.forEach(image => {
    const aspectRatio = image.width / image.height;
    const area = image.width * image.height;
    
    if (aspectRatio > 1.8 && area > 100000) {
      charts++; // Wide, large format likely charts/graphs
    } else if (aspectRatio < 0.6) {
      diagrams++; // Tall format likely diagrams/flowcharts
    } else if (aspectRatio > 1.2 && aspectRatio < 1.8) {
      tables++; // Rectangular format likely tables
    } else if (Math.abs(aspectRatio - 1) < 0.3) {
      photos++; // Square-ish likely photos/icons
    } else {
      mixed++; // Other formats
    }
  });
  
  if (charts > 0) types.push({
    type: 'Chart/Graph', 
    count: charts, 
    description: 'Data visualizations, statistical charts, and analytical graphs presenting quantitative information'
  });
  
  if (diagrams > 0) types.push({
    type: 'Diagram/Flowchart', 
    count: diagrams, 
    description: 'Process flows, organizational charts, and structural diagrams illustrating relationships and processes'
  });
  
  if (tables > 0) types.push({
    type: 'Table/Data Grid', 
    count: tables, 
    description: 'Structured data presentations, comparison tables, and organized information matrices'
  });
  
  if (photos > 0) types.push({
    type: 'Image/Illustration', 
    count: photos, 
    description: 'Photographs, illustrations, and visual representations supporting textual content'
  });
  
  if (mixed > 0) types.push({
    type: 'Mixed Format', 
    count: mixed, 
    description: 'Various visual elements including screenshots, composite images, and specialized formats'
  });
  
  return types;
}

function generateDetailedImageAnalysis(image: ExtractedImage, text: string, domain?: string): {
  description: string;
  technical: string;
  significance: string;
  context: string;
} {
  const aspectRatio = image.width / image.height;
  const area = image.width * image.height;
  
  // Determine detailed image type and characteristics
  let imageType = 'visual element';
  let characteristics = '';
  
  if (aspectRatio > 1.8) {
    imageType = 'wide-format chart or graph';
    characteristics = 'optimized for displaying trends, comparisons, or time-series data';
  } else if (aspectRatio < 0.6) {
    imageType = 'vertical diagram or flowchart';
    characteristics = 'designed to show hierarchical relationships or sequential processes';
  } else if (aspectRatio > 1.2 && aspectRatio < 1.8) {
    imageType = 'structured table or data grid';
    characteristics = 'formatted for organized data presentation and comparison';
  } else if (Math.abs(aspectRatio - 1) < 0.3) {
    imageType = 'square format image or icon';
    characteristics = 'balanced composition suitable for illustrations or symbolic representations';
  } else {
    imageType = 'standard format visual';
    characteristics = 'versatile layout appropriate for various content types';
  }
  
  const description = image.explanation || 
    `This ${imageType} presents ${getDomainSpecificContent(domain)} information in a visually accessible format. The visual element demonstrates ${characteristics} and serves to enhance reader comprehension of complex concepts discussed in the surrounding text. The content appears to be professionally designed and integrated strategically within the document structure.`;
  
  const technical = `Technical Specifications: ${Math.round(image.width)}×${Math.round(image.height)} pixels (${(area/1000000).toFixed(2)}MP), Aspect Ratio: ${aspectRatio.toFixed(2)}:1. The image quality and resolution are ${area > 500000 ? 'high-definition, suitable for detailed analysis' : area > 200000 ? 'standard quality, appropriate for document integration' : 'optimized for document viewing'}. Format characteristics suggest ${imageType} with ${characteristics}.`;
  
  const significance = `This visual element plays a crucial role in the document's educational and informational objectives. It provides ${domain === 'academic' ? 'empirical evidence and research validation' : domain === 'business' ? 'strategic insights and performance metrics' : domain === 'technical' ? 'technical specifications and implementation details' : 'supporting evidence and conceptual clarification'} that complements the textual narrative and enhances overall document effectiveness.`;
  
  const context = `Positioned strategically on page ${image.pageNumber}, this visual element is integrated within the document's logical flow to support key arguments and facilitate understanding. The placement suggests it directly relates to ${findRelatedContent(text, image.pageNumber)} and serves to bridge theoretical concepts with practical applications. The visual contributes to the document's comprehensive approach to knowledge transfer and professional communication.`;
  
  return { description, technical, significance, context };
}

function getDomainSpecificContent(domain?: string): string {
  const contentTypes: Record<string, string> = {
    academic: 'research data, statistical analysis, or scholarly',
    business: 'strategic analysis, performance metrics, or market',
    medical: 'clinical data, diagnostic information, or healthcare',
    legal: 'regulatory compliance, legal framework, or procedural',
    financial: 'financial performance, market analysis, or economic',
    technical: 'system specifications, technical processes, or engineering',
    educational: 'learning objectives, instructional content, or pedagogical'
  };
  
  return contentTypes[domain || 'general'] || 'professional, informational, or analytical';
}

function findRelatedContent(text: string, pageNumber: number): string {
  const pageRef = `page ${pageNumber}`;
  const sentences = text.split(/[.!?]+/);
  
  // Look for sentences that might relate to this page
  const relatedSentences = sentences.filter(sentence => 
    sentence.toLowerCase().includes('figure') ||
    sentence.toLowerCase().includes('table') ||
    sentence.toLowerCase().includes('chart') ||
    sentence.toLowerCase().includes('diagram') ||
    sentence.toLowerCase().includes('illustration')
  );
  
  if (relatedSentences.length > 0) {
    return `content discussing ${relatedSentences[0].trim().substring(0, 100)}...`;
  }
  
  return 'the main thematic content of this section';
}

function extractDataInsights(text: string): string[] {
  const insights: string[] = [];
  
  // Enhanced numerical data detection
  const percentages = text.match(/\d+(?:\.\d+)?%/g);
  if (percentages && percentages.length > 0) {
    insights.push(`Document contains ${percentages.length} percentage values ranging from statistical data to performance metrics`);
  }
  
  const monetaryValues = text.match(/\$\d+(?:,\d{3})*(?:\.\d{2})?|\d+(?:,\d{3})*\s*(?:dollars?|USD|million|billion)/gi);
  if (monetaryValues && monetaryValues.length > 0) {
    insights.push(`Financial data includes ${monetaryValues.length} monetary references indicating economic analysis or budget information`);
  }
  
  const numericalData = text.match(/\d+(?:,\d{3})*(?:\.\d+)?/g);
  if (numericalData && numericalData.length > 10) {
    insights.push(`Extensive numerical data with ${numericalData.length} quantitative references supporting analytical conclusions`);
  }
  
  // Statistical terminology
  const statTerms = text.match(/\b(average|mean|median|mode|standard deviation|correlation|regression|analysis|significant|p-value|confidence|interval)\b/gi);
  if (statTerms && statTerms.length > 5) {
    insights.push(`Statistical analysis terminology appears ${statTerms.length} times, indicating quantitative research methodology`);
  }
  
  // Comparative analysis
  const comparisons = text.match(/\b(increased|decreased|higher|lower|compared to|versus|greater than|less than|improvement|decline|growth|reduction)\b/gi);
  if (comparisons && comparisons.length > 5) {
    insights.push(`Comparative analysis with ${comparisons.length} references to trends, changes, and performance variations`);
  }
  
  // Time-based data
  const timeReferences = text.match(/\b(year|month|quarter|annual|monthly|weekly|daily|\d{4}|january|february|march|april|may|june|july|august|september|october|november|december)\b/gi);
  if (timeReferences && timeReferences.length > 5) {
    insights.push(`Temporal data analysis with ${timeReferences.length} time-based references indicating longitudinal or periodic analysis`);
  }
  
  return insights.slice(0, 8);
}

function generateDetailedContentSlides(extractedContent: ExtractedContent, summaryResults: SummaryResult[]): Array<{
  title: string;
  content: string;
  keyPoints: string[];
}> {
  const slides: Array<{title: string; content: string; keyPoints: string[]}> = [];
  
  // Generate multiple detailed content slides
  summaryResults.forEach((result, index) => {
    let slideTitle = '';
    let enhancedContent = '';
    
    switch (result.model) {
      case 'bert':
        slideTitle = 'Contextual Content Analysis';
        enhancedContent = `CONTEXTUAL UNDERSTANDING AND SEMANTIC ANALYSIS

${result.content}

This analysis reveals the deep contextual relationships within the document, identifying key semantic patterns and domain-specific terminology. The content demonstrates sophisticated understanding of subject matter through:

• Contextual word relationships and semantic dependencies
• Domain-specific terminology usage and technical language patterns  
• Conceptual frameworks and theoretical foundations
• Cross-referential content connections and thematic consistency

The document maintains high contextual coherence throughout its structure, facilitating comprehensive understanding of complex topics through well-established semantic relationships.`;
        break;
        
      case 'lstm':
        slideTitle = 'Document Structure & Information Architecture';
        enhancedContent = `SEQUENTIAL ANALYSIS AND STRUCTURAL ORGANIZATION

${result.content}

This structural analysis examines the document's information architecture and sequential flow patterns. Key organizational elements include:

• Logical progression of ideas and concept development
• Hierarchical information structure and content layering
• Sequential dependencies and information building blocks
• Transitional elements and narrative flow continuity

The document demonstrates excellent structural integrity with clear information pathways that guide readers through complex material systematically and effectively.`;
        break;
        
      case 'multimodel':
        slideTitle = 'Comprehensive Content Integration';
        enhancedContent = `MULTIMODAL CONTENT SYNTHESIS AND INTEGRATION

${result.content}

This comprehensive analysis integrates textual and visual elements to provide holistic understanding. The integration reveals:

• Synergistic relationships between text and visual content
• Enhanced comprehension through multimodal presentation
• Complementary information delivery across different media types
• Unified narrative supported by diverse content formats

The document achieves effective multimodal communication, leveraging both textual depth and visual clarity to maximize information transfer and reader engagement.`;
        break;
    }
    
    slides.push({
      title: slideTitle,
      content: enhancedContent,
      keyPoints: result.keyPoints
    });
  });
  
  return slides;
}

function extractDetailedConclusions(text: string, summaryResults: SummaryResult[]): Array<{
  title: string;
  content: string;
  implications: string[];
}> {
  const conclusions: Array<{title: string; content: string; implications: string[]}> = [];
  
  // Look for conclusion patterns
  const conclusionSentences = text.split(/[.!?]+/).filter(s => 
    /\b(conclusion|summary|result|finding|therefore|thus|in summary|to conclude|finally|ultimately)\b/i.test(s) && 
    s.trim().length > 80
  );
  
  if (conclusionSentences.length > 0) {
    conclusionSentences.slice(0, 5).forEach((sentence, index) => {
      const implications = findImplications(text, sentence);
      conclusions.push({
        title: `Primary Finding ${index + 1}`,
        content: sentence.trim() + '. This finding represents a significant contribution to the overall understanding of the subject matter and provides valuable insights for practical application and further research.',
        implications
      });
    });
  } else {
    // Generate conclusions from analysis results
    summaryResults.forEach((result, index) => {
      const implications = result.keyPoints.slice(0, 3);
      conclusions.push({
        title: `Key Insight ${index + 1}`,
        content: `Based on the comprehensive analysis, ${result.content.substring(0, 300)}... This insight provides crucial understanding of the document's core themes and contributes to the overall knowledge framework presented.`,
        implications
      });
    });
  }
  
  return conclusions.slice(0, 4);
}

function findImplications(text: string, conclusion: string): string[] {
  const implications: string[] = [];
  const sentences = text.split(/[.!?]+/);
  
  // Look for sentences with implication keywords
  sentences.forEach(sentence => {
    if ((sentence.toLowerCase().includes('implication') ||
         sentence.toLowerCase().includes('consequence') ||
         sentence.toLowerCase().includes('result') ||
         sentence.toLowerCase().includes('impact')) &&
        sentence.trim().length > 50) {
      implications.push(sentence.trim());
    }
  });
  
  // If no specific implications found, generate generic ones
  if (implications.length === 0) {
    implications.push(
      'Provides foundation for future research and development in this area',
      'Offers practical insights applicable to professional practice',
      'Contributes to theoretical understanding and knowledge advancement'
    );
  }
  
  return implications.slice(0, 4);
}

function generateComprehensiveDocumentSummary(extractedContent: ExtractedContent, summaryResults: SummaryResult[]): string {
  const domain = extractedContent.domain || 'general';
  const avgConfidence = summaryResults.reduce((sum, result) => sum + result.confidence, 0) / summaryResults.length;
  const readingTime = Math.ceil(extractedContent.wordCount / 200);
  
  return `COMPREHENSIVE DOCUMENT ANALYSIS SUMMARY

This ${domain} document represents a comprehensive resource containing ${extractedContent.wordCount.toLocaleString()} words across ${extractedContent.pageCount} pages, requiring approximately ${readingTime} minutes for complete review.

CONTENT QUALITY & DEPTH:
The document demonstrates exceptional quality in content organization, depth of coverage, and professional presentation. Analysis reveals ${Math.round(avgConfidence * 100)}% confidence in content accuracy and relevance, indicating high-quality source material with reliable information.

STRUCTURAL EXCELLENCE:
• Well-organized hierarchical structure facilitating easy navigation
• Logical progression of concepts from fundamental to advanced topics
• Clear section delineation with appropriate transitional elements
• Professional formatting and presentation standards throughout

VISUAL INTEGRATION:
${extractedContent.imageCount > 0 ? 
  `The document incorporates ${extractedContent.imageCount} visual elements that significantly enhance comprehension and provide empirical support for textual content. These visuals demonstrate professional quality and strategic placement for maximum educational impact.` :
  'The document maintains focus on comprehensive textual explanation with clear narrative structure and detailed conceptual development.'
}

DOMAIN EXPERTISE:
The content reflects deep understanding of ${domain} principles, incorporating appropriate terminology, methodologies, and analytical frameworks. The document serves as an authoritative reference for professionals and researchers in the field.

PRACTICAL VALUE:
This document provides substantial practical value through its comprehensive coverage, professional insights, and actionable information. It serves as an excellent resource for understanding complex topics and can be effectively utilized for educational, professional, or research purposes.

OVERALL ASSESSMENT:
This document represents a high-quality, professionally developed resource that effectively communicates complex information through well-structured content, appropriate visual support, and comprehensive coverage of relevant topics. It stands as a valuable contribution to ${domain} literature and professional knowledge.`;
}