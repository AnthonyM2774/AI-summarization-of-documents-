import * as pdfjsLib from 'pdfjs-dist';
import { ExtractedImage } from '../types';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

export interface PDFContent {
  text: string;
  pageCount: number;
  wordCount: number;
  imageCount: number;
  images: ExtractedImage[];
}

export class PDFService {
  async extractContent(file: File): Promise<PDFContent> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      let fullText = '';
      const images: ExtractedImage[] = [];
      
      // Extract text and images from each page
      for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        
        // Combine text items
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        
        fullText += pageText + '\n';
        
        // Always try to extract visual content from each page
        try {
          const pageImage = await this.extractPageVisualContent(page, pageNum);
          if (pageImage) {
            images.push(pageImage);
          }
        } catch (error) {
          console.warn(`Could not extract visual content from page ${pageNum}:`, error);
        }
      }
      
      // Clean up text
      const cleanText = fullText
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim();
      
      const wordCount = cleanText.split(/\s+/).filter(word => word.length > 0).length;
      
      return {
        text: cleanText,
        pageCount: pdf.numPages,
        wordCount,
        imageCount: images.length,
        images
      };
    } catch (error) {
      console.error('PDF extraction error:', error);
      throw new Error('Failed to extract content from PDF');
    }
  }

  private async extractPageVisualContent(page: any, pageNum: number): Promise<ExtractedImage | null> {
    try {
      // Render the page to canvas
      const scale = 2.0; // Higher scale for better quality
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      if (!context) return null;
      
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      
      // Fill with white background
      context.fillStyle = 'white';
      context.fillRect(0, 0, canvas.width, canvas.height);

      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };

      // Render the page
      await page.render(renderContext).promise;
      
      // Check if this page has significant visual content
      const hasVisualContent = await this.analyzePageForVisualContent(context, canvas.width, canvas.height);
      
      if (hasVisualContent) {
        return {
          id: `page-${pageNum}-content`,
          pageNumber: pageNum,
          dataUrl: canvas.toDataURL('image/png', 0.9),
          width: viewport.width,
          height: viewport.height
        };
      }
      
      return null;
    } catch (error) {
      console.error(`Error extracting visual content from page ${pageNum}:`, error);
      return null;
    }
  }

  private async analyzePageForVisualContent(context: CanvasRenderingContext2D, width: number, height: number): Promise<boolean> {
    try {
      // Get image data for analysis
      const imageData = context.getImageData(0, 0, width, height);
      const data = imageData.data;
      
      // Sample pixels for performance (every 16th pixel)
      const sampleStep = 16;
      let totalSamples = 0;
      let nonWhitePixels = 0;
      let colorVariance = 0;
      let edgePixels = 0;
      
      // Analyze pixel distribution
      for (let y = 0; y < height; y += sampleStep) {
        for (let x = 0; x < width; x += sampleStep) {
          const index = (y * width + x) * 4;
          if (index + 3 < data.length) {
            const r = data[index];
            const g = data[index + 1];
            const b = data[index + 2];
            
            totalSamples++;
            
            // Check if pixel is not white/near-white
            const brightness = (r + g + b) / 3;
            if (brightness < 240) {
              nonWhitePixels++;
              
              // Calculate color variance (indicates charts, images, etc.)
              const variance = Math.abs(r - g) + Math.abs(g - b) + Math.abs(r - b);
              colorVariance += variance;
              
              // Check for edges (sudden brightness changes)
              if (x > 0 && y > 0) {
                const prevIndex = (y * width + (x - sampleStep)) * 4;
                if (prevIndex + 3 < data.length) {
                  const prevBrightness = (data[prevIndex] + data[prevIndex + 1] + data[prevIndex + 2]) / 3;
                  if (Math.abs(brightness - prevBrightness) > 50) {
                    edgePixels++;
                  }
                }
              }
            }
          }
        }
      }
      
      if (totalSamples === 0) return false;
      
      const nonWhiteRatio = nonWhitePixels / totalSamples;
      const avgColorVariance = colorVariance / Math.max(nonWhitePixels, 1);
      const edgeRatio = edgePixels / totalSamples;
      
      // Determine if page has significant visual content
      const hasSignificantContent = (
        nonWhiteRatio > 0.05 && // At least 5% non-white pixels
        (
          avgColorVariance > 10 || // Has colorful content (charts, images)
          edgeRatio > 0.02 || // Has edges (diagrams, shapes)
          nonWhitePixels > 200 // Sufficient visual elements
        )
      );
      
      // Additional check: look for structured visual patterns
      if (!hasSignificantContent && nonWhiteRatio > 0.02) {
        // Check for patterns that might indicate charts or diagrams
        const hasPatterns = this.detectVisualPatterns(data, width, height, sampleStep);
        return hasPatterns;
      }
      
      return hasSignificantContent;
    } catch (error) {
      console.error('Error analyzing visual content:', error);
      return false;
    }
  }

  private detectVisualPatterns(data: Uint8ClampedArray, width: number, height: number, step: number): boolean {
    try {
      let horizontalLines = 0;
      let verticalLines = 0;
      let rectangularShapes = 0;
      
      // Look for line patterns
      for (let y = step; y < height - step; y += step * 2) {
        let consecutivePixels = 0;
        for (let x = 0; x < width; x += step) {
          const index = (y * width + x) * 4;
          const brightness = (data[index] + data[index + 1] + data[index + 2]) / 3;
          
          if (brightness < 200) {
            consecutivePixels++;
          } else {
            if (consecutivePixels > 10) {
              horizontalLines++;
            }
            consecutivePixels = 0;
          }
        }
      }
      
      // Look for vertical patterns
      for (let x = step; x < width - step; x += step * 2) {
        let consecutivePixels = 0;
        for (let y = 0; y < height; y += step) {
          const index = (y * width + x) * 4;
          const brightness = (data[index] + data[index + 1] + data[index + 2]) / 3;
          
          if (brightness < 200) {
            consecutivePixels++;
          } else {
            if (consecutivePixels > 10) {
              verticalLines++;
            }
            consecutivePixels = 0;
          }
        }
      }
      
      // Look for rectangular regions (potential charts/tables)
      for (let y = 0; y < height - step * 4; y += step * 4) {
        for (let x = 0; x < width - step * 4; x += step * 4) {
          let darkPixels = 0;
          let totalPixels = 0;
          
          // Check a small rectangular region
          for (let dy = 0; dy < step * 4; dy += step) {
            for (let dx = 0; dx < step * 4; dx += step) {
              const index = ((y + dy) * width + (x + dx)) * 4;
              if (index + 3 < data.length) {
                const brightness = (data[index] + data[index + 1] + data[index + 2]) / 3;
                totalPixels++;
                if (brightness < 220) {
                  darkPixels++;
                }
              }
            }
          }
          
          // If region has consistent content, it might be a chart/table
          if (totalPixels > 0 && darkPixels / totalPixels > 0.3 && darkPixels / totalPixels < 0.8) {
            rectangularShapes++;
          }
        }
      }
      
      // Determine if patterns suggest visual content
      return horizontalLines > 2 || verticalLines > 2 || rectangularShapes > 1;
    } catch (error) {
      console.error('Error detecting visual patterns:', error);
      return false;
    }
  }
}

export const pdfService = new PDFService();