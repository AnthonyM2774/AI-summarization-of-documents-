import { useState, useCallback } from 'react';
import { pdfService } from '../services/pdfService';
import { geminiService } from '../services/geminiService';

export interface SummaryResult {
  id: string;
  model: 'bert' | 'lstm' | 'multimodel';
  title: string;
  content: string;
  confidence: number;
  processingTime: number;
  keyPoints: string[];
  domain?: string;
}

export interface ExtractedContent {
  text: string;
  imageCount: number;
  pageCount: number;
  wordCount: number;
  images: ExtractedImage[];
  domain?: string;
}

export interface ExtractedImage {
  id: string;
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  explanation?: string;
}

export interface ProcessingStep {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}

export const usePDFProcessor = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [extractedContent, setExtractedContent] = useState<ExtractedContent | null>(null);
  const [summaryResults, setSummaryResults] = useState<SummaryResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  const processWithRealAPI = useCallback(async (file: File, domain?: string) => {
    setIsProcessing(true);
    setError(null);
    
    // Check API availability
    const apiStatus = geminiService.getAnalysisStatus();
    setIsOfflineMode(!apiStatus.gemini && !apiStatus.llama);
    
    setProcessingSteps([
      { id: '1', name: 'Extracting PDF content and graphics', status: 'processing', progress: 0 },
      { id: '2', name: 'Contextual analysis and understanding', status: 'pending', progress: 0 },
      { id: '3', name: 'Sequential processing and structure analysis', status: 'pending', progress: 0 },
      { id: '4', name: 'Multimodal fusion and integration', status: 'pending', progress: 0 },
      { id: '5', name: 'Visual content analysis and interpretation', status: 'pending', progress: 0 }
    ]);

    try {
      // Step 1: Extract content
      const pdfContent = await pdfService.extractContent(file);
      
      setProcessingSteps(prev => prev.map(step => 
        step.id === '1' ? { ...step, status: 'completed', progress: 100 } :
        step.id === '2' ? { ...step, status: 'processing', progress: 0 } : step
      ));

      const extractedContent: ExtractedContent = {
        text: pdfContent.text,
        imageCount: pdfContent.imageCount,
        pageCount: pdfContent.pageCount,
        wordCount: pdfContent.wordCount,
        images: pdfContent.images,
        domain: domain || 'general'
      };
      setExtractedContent(extractedContent);

      // Step 2: BERT Analysis
      const bertAnalysis = await geminiService.analyzeBERT(pdfContent.text, domain || 'general');
      setProcessingSteps(prev => prev.map(step => 
        step.id === '2' ? { ...step, status: 'completed', progress: 100 } :
        step.id === '3' ? { ...step, status: 'processing', progress: 0 } : step
      ));

      // Step 3: LSTM Analysis
      const lstmAnalysis = await geminiService.analyzeLSTM(pdfContent.text, domain || 'general');
      setProcessingSteps(prev => prev.map(step => 
        step.id === '3' ? { ...step, status: 'completed', progress: 100 } :
        step.id === '4' ? { ...step, status: 'processing', progress: 0 } : step
      ));

      // Step 4: Multimodal Analysis
      const multimodalAnalysis = await geminiService.analyzeMultimodal(
        pdfContent.text, 
        pdfContent.images, 
        domain || 'general'
      );
      setProcessingSteps(prev => prev.map(step => 
        step.id === '4' ? { ...step, status: 'completed', progress: 100 } :
        step.id === '5' ? { ...step, status: 'processing', progress: 0 } : step
      ));

      // Step 5: Analyze images with AI
      const updatedImages = await Promise.all(
        pdfContent.images.map(async (image) => {
          try {
            const explanation = await geminiService.analyzeImageContent(image, domain || 'general');
            return { ...image, explanation };
          } catch (error) {
            console.warn(`Failed to analyze image ${image.id}:`, error);
            return image;
          }
        })
      );

      setProcessingSteps(prev => prev.map(step => 
        step.id === '5' ? { ...step, status: 'completed', progress: 100 } : step
      ));

      // Update extracted content with analyzed images
      const finalExtractedContent = {
        ...extractedContent,
        images: updatedImages
      };
      setExtractedContent(finalExtractedContent);

      // Set all analysis results
      setSummaryResults([bertAnalysis, lstmAnalysis, multimodalAnalysis]);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during processing');
      setProcessingSteps(prev => prev.map(step => 
        step.status === 'processing' ? { ...step, status: 'error' } : step
      ));
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const resetProcessor = useCallback(() => {
    setIsProcessing(false);
    setProcessingSteps([]);
    setExtractedContent(null);
    setSummaryResults([]);
    setError(null);
    setIsOfflineMode(false);
  }, []);

  return {
    isProcessing,
    processingSteps,
    extractedContent,
    summaryResults,
    error,
    isOfflineMode,
    processWithRealAPI,
    resetProcessor
  };
};