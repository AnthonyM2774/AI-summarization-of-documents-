export interface SummaryResult {
  id: string;
  model: 'bert' | 'lstm' | 'multimodel';
  title: string;
  content: string;
  confidence: number;
  processingTime: number;
  keyPoints: string[];
  domain?: string;
}

export interface ExtractedContent {
  text: string;
  imageCount: number;
  pageCount: number;
  wordCount: number;
  images: ExtractedImage[];
  domain?: string;
}

export interface ExtractedImage {
  id: string;
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  explanation?: string;
}

export interface ProcessingStep {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
}