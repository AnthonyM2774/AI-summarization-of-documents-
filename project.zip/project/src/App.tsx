import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { ProcessingSteps } from './components/ProcessingSteps';
import { ExtractedContentDisplay } from './components/ExtractedContent';
import { SummaryCard } from './components/SummaryCard';
import { InfoSection } from './components/InfoSection';
import { ErrorDisplay } from './components/ErrorDisplay';
import { DomainSelector } from './components/DomainSelector';
import { usePDFProcessor } from './hooks/usePDFProcessor';
import { AlertTriangle, RefreshCw, WifiOff } from 'lucide-react';

function App() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedDomain, setSelectedDomain] = useState<string>('general');
  const {
    isProcessing,
    processingSteps,
    extractedContent,
    summaryResults,
    error,
    isOfflineMode,
    processWithRealAPI,
    resetProcessor,
  } = usePDFProcessor();

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
  };

  const handleFileRemove = () => {
    setSelectedFile(null);
    resetProcessor();
  };

  const handleDomainChange = (domain: string) => {
    setSelectedDomain(domain);
  };

  const handleStartProcessing = async () => {
    if (selectedFile) {
      await processWithRealAPI(selectedFile, selectedDomain);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setSelectedDomain('general');
    resetProcessor();
  };

  const handleRetry = () => {
    if (selectedFile) {
      resetProcessor();
      setTimeout(() => {
        processWithRealAPI(selectedFile, selectedDomain);
      }, 500);
    }
  };

  return (
    <div className="min-h-screen bg-dark-950">
      <Header />
      
      {/* Offline Mode Indicator */}
      <AnimatePresence>
        {isOfflineMode && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="bg-amber-900/20 border-b border-amber-600/30"
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
              <div className="flex items-center justify-center space-x-2 text-amber-300">
                <WifiOff className="h-5 w-5" />
                <span className="text-sm font-medium">
                  Operating in Offline Mode - API quota reached. Analysis continues with local processing.
                </span>
                <a
                  href="https://ai.google.dev/gemini-api/docs/rate-limits"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-400 hover:text-amber-200 underline text-sm"
                >
                  Learn more
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Upload Section */}
        <div className="mb-8">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-100 mb-2">
                Upload Your Document
              </h2>
              <p className="text-gray-400">
                Get context-aware domain-specific summaries of documents with text and graphics
              </p>
            </div>
            
            <FileUpload
              onFileSelect={handleFileSelect}
              selectedFile={selectedFile}
              onFileRemove={handleFileRemove}
              isProcessing={isProcessing}
            />

            {selectedFile && !isProcessing && processingSteps.length === 0 && !error && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 space-y-4"
              >
                <DomainSelector
                  selectedDomain={selectedDomain}
                  onDomainChange={handleDomainChange}
                />
                
                <div className="text-center">
                  <button
                    onClick={handleStartProcessing}
                    className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-lg shadow-sm text-white bg-gradient-to-r from-cyber-600 to-electric-600 hover:from-cyber-700 hover:to-electric-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyber-500 transition-all duration-300"
                  >
                    Start Context-Aware Analysis
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* Error Display */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <ErrorDisplay error={error} onRetry={handleRetry} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Processing Steps */}
        <AnimatePresence>
          {processingSteps.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <ProcessingSteps steps={processingSteps} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Content Grid */}
        <AnimatePresence>
          {extractedContent && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid lg:grid-cols-3 gap-8 mb-8"
            >
              <div className="lg:col-span-1">
                <ExtractedContentDisplay content={extractedContent} />
              </div>
              
              <div className="lg:col-span-2 space-y-6">
                {summaryResults.map((summary, index) => (
                  <SummaryCard key={summary.id} summary={summary} index={index} />
                ))}
                
                {summaryResults.length > 0 && !isProcessing && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="text-center pt-6"
                  >
                    <button
                      onClick={handleReset}
                      className="inline-flex items-center px-6 py-3 border-2 border-cyber-500 text-base font-medium rounded-lg text-white bg-dark-700 hover:bg-dark-600 hover:border-cyber-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyber-500 transition-all duration-300 shadow-lg"
                    >
                      <RefreshCw className="h-5 w-5 mr-2" />
                      Process Another Document
                    </button>
                  </motion.div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <InfoSection />
      
      <footer className="bg-dark-900 border-t border-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-400">
              Context-Aware Domain-Specific Document Summarizer - Advanced AI for Text & Graphics Analysis
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;